package utils;

/**
 * This class not used at this time.
 */
public class TimeFiles {

}
