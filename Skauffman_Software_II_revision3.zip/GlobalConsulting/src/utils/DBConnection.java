package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * DBConnection Class.
 * @author Susan Kauffman
 */
public class DBConnection {

    //JDBC url parts
    private static final String protocol = "jdbc";
    private static final String vendorName = ":mysql:";
    private static final String ipAddress = "//wgudb.ucertify.com/WJ06RUD";

    private static final String jdbcURL = protocol + vendorName + ipAddress;
    //Driver interface reference
    private static final String MYSQLJDBCDriver = "com.mysql.cj.jdbc.Driver";
    private static Connection conn = null;

    private static final String username = "U06RUD";
    private static String password = "53688847504";

    /**
     * Database Connection.
     * @return conn
     */
    public static Connection startConnection() {
        try {
            Class.forName(MYSQLJDBCDriver);
            conn = (Connection) DriverManager.getConnection(jdbcURL, username, password);
            System.out.println("Connection was successful");
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
        return conn;
    }

    /**
     * Getter for the connection.
     * @return conn
     */
    public static Connection getConnection(){
        return conn;
    }

    /**
     * Closes the connection.
     */
    public static void closeConnection() {
        try {
            conn.close();
            System.out.println("Connection Closed!");
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}