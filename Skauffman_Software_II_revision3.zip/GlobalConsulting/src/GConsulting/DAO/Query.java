package GConsulting.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * This is the Query Class.
 * @author Susan Kauffman
 */
public class Query {

    private static PreparedStatement statement;

    /**
     * The setter for the Query class prepared statement.
     */
    public static void setPreparedStatement(Connection conn, String sqlStatement) throws SQLException
    {
        statement = conn.prepareStatement(sqlStatement);
    }

    /**
     * The getter for the Query class prepared statement.
     */
    public static PreparedStatement getPreparedStatement() {
        return statement;

    }
}
