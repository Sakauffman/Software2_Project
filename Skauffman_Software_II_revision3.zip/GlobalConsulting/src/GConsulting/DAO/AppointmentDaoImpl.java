package GConsulting.DAO;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Appointment;
import model.Contact;
import model.Customer;
import model.User;
import utils.DBConnection;

import java.sql.*;
import java.time.LocalDateTime;

/**
 * The appointment DAO implementation class.
 * @author Susan Kauffman
 */
public class AppointmentDaoImpl {

    /**
     * A method to delete an appointment from the database.
     * @param appointment
     * @throws SQLException
     */

    public void deleteAppointment(Appointment appointment) throws SQLException {
        Connection conn = DBConnection.getConnection();
        String deleteStatement = "DELETE FROM appointments WHERE Appointment_ID = ?";
        Query.setPreparedStatement(conn, deleteStatement);
        PreparedStatement ps = Query.getPreparedStatement();

        ps.setInt(1, appointment.getAppointmentId());

        ps.execute();

    }

    /**
     * A method to insert an appointment into the database.
     * @param appointment
     * @throws SQLException
     */

   public void setAppointment(Appointment appointment) throws SQLException {
       Connection conn = DBConnection.getConnection();
       String insertStatement = "INSERT INTO appointments(Title, Description, Location, Type, Start, End, Customer_ID, User_ID, Contact_ID) VALUES (?,?,?,?,?,?,?,?,?)";
       Query.setPreparedStatement(conn, insertStatement);
       PreparedStatement ps = Query.getPreparedStatement();

       ps.setString(1, appointment.getAppointmentTitle());
       ps.setString(2, appointment.getAppointmentDescription());
       ps.setString(3, appointment.getAppointmentLocation());
       ps.setString(4, appointment.getAppointmentType());
       ps.setTimestamp(5, Timestamp.valueOf(appointment.getAppointmentStartTime()));
       ps.setTimestamp(6, Timestamp.valueOf(appointment.getAppointmentEndTime()));
       ps.setInt(7, appointment.getCustomerId());
       ps.setInt(8, appointment.getAppointmentUserId());
       ps.setInt(9, appointment.getAppointmentContactId());

       ps.execute();

    }

    /**
     * A method to get all appointments in the database.
     * @return allAppointments
     */
    public static ObservableList<Appointment> getAppointment(){
        ObservableList<Appointment> allAppointments = FXCollections.observableArrayList();

        Connection conn = DBConnection.getConnection();

        String selectStatement = "SELECT * FROM appointments";
        try {
            Query.setPreparedStatement(conn, selectStatement);


            PreparedStatement statement = Query.getPreparedStatement();
            statement.executeQuery();

            ResultSet rs = statement.getResultSet();


            while (rs.next()) {
                int appointIdReturned = rs.getInt("Appointment_ID");
                String apptTitleReturned = rs.getString("Title");
                String apptDescrReturned = rs.getString("Description");
                String apptLocationReturned = rs.getString("Location");
                int apptContactReturned = rs.getInt("Contact_ID");
                int apptUserIdReturned = rs.getInt("User_ID");
                String apptTypeReturned = rs.getString("Type");
                Timestamp startDTReturned = rs.getTimestamp("Start");
                Timestamp endDTReturned = rs.getTimestamp("End");
                int customerIdReturned = rs.getInt("Customer_ID");
                startDTReturned.toLocalDateTime();
                endDTReturned.toLocalDateTime();

                allAppointments.add(new Appointment(appointIdReturned, customerIdReturned, apptTitleReturned, apptDescrReturned, apptLocationReturned, apptTypeReturned, apptContactReturned, apptUserIdReturned, startDTReturned.toLocalDateTime(), endDTReturned.toLocalDateTime()));

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return allAppointments;

    }

    /**
     * A method to update an appointment in the database.
     * @param appointment
     * @throws SQLException
     */
    public void updateAppointment(Appointment appointment) throws SQLException {
        Connection conn = DBConnection.getConnection();
        String updateStatement = "UPDATE appointments SET Title = ?, Description = ?, Location = ?, Type = ?, Start = ?, End = ?, Customer_ID = ?, User_ID = ?, Contact_ID = ? WHERE Appointment_ID = ?;";
        Query.setPreparedStatement(conn, updateStatement);
        PreparedStatement ps = Query.getPreparedStatement();

        ps.setString(1, appointment.getAppointmentTitle());
        ps.setString(2, appointment.getAppointmentDescription());
        ps.setString(3, appointment.getAppointmentLocation());
        ps.setString(4, appointment.getAppointmentType());
        ps.setTimestamp(5, Timestamp.valueOf(appointment.getAppointmentStartTime()));
        ps.setTimestamp(6, Timestamp.valueOf(appointment.getAppointmentEndTime()));
        ps.setInt(7, appointment.getCustomerId());
        ps.setInt(8, appointment.getAppointmentUserId());
        ps.setInt(9, appointment.getAppointmentContactId());
        ps.setInt(10, appointment.getAppointmentId());

        ps.executeUpdate();
    }

    /**
     * A method to get appointments for one week.
     * @return weekAppts
     */

    public static ObservableList<Appointment> weeklyAppointments(){
        ObservableList<Appointment> weekAppts = FXCollections.observableArrayList();

        Connection conn = DBConnection.getConnection();

        String selectStatement = "Select * from appointments WHERE date(Start) between current_date() AND current_date() + interval 6 day";
        try {
            Query.setPreparedStatement(conn, selectStatement);


            PreparedStatement statement = Query.getPreparedStatement();
            statement.executeQuery();

            ResultSet rs = statement.getResultSet();

            while (rs.next()) {
                int appointIdReturned = rs.getInt("Appointment_ID");
                String apptTitleReturned = rs.getString("Title");
                String apptDescrReturned = rs.getString("Description");
                String apptLocationReturned = rs.getString("Location");
                int apptContactReturned = rs.getInt("Contact_ID");
                int apptUserIdReturned = rs.getInt("User_ID");
                String apptTypeReturned = rs.getString("Type");
                Timestamp startDTReturned = rs.getTimestamp("Start");
                Timestamp endDTReturned = rs.getTimestamp("End");
                int customerIdReturned = rs.getInt("Customer_ID");
                startDTReturned.toLocalDateTime();
                endDTReturned.toLocalDateTime();

                weekAppts.add(new Appointment(appointIdReturned, customerIdReturned, apptTitleReturned, apptDescrReturned, apptLocationReturned, apptTypeReturned, apptContactReturned, apptUserIdReturned, startDTReturned.toLocalDateTime(), endDTReturned.toLocalDateTime()));

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return weekAppts;

    }

    /**
     * A method to get appointments for a month.
     * @return monthAppts
     */
    public static ObservableList<Appointment> monthlyAppointments(){
        ObservableList<Appointment> monthAppts = FXCollections.observableArrayList();

        Connection conn = DBConnection.getConnection();

        String selectStatement = "Select * from appointments WHERE date(Start) between current_date() AND current_date() + interval 30 day";
        try {
            Query.setPreparedStatement(conn, selectStatement);


            PreparedStatement statement = Query.getPreparedStatement();
            statement.executeQuery();

            ResultSet rs = statement.getResultSet();

            while (rs.next()) {
                int appointIdReturned = rs.getInt("Appointment_ID");
                String apptTitleReturned = rs.getString("Title");
                String apptDescrReturned = rs.getString("Description");
                String apptLocationReturned = rs.getString("Location");
                int apptContactReturned = rs.getInt("Contact_ID");
                int apptUserIdReturned = rs.getInt("User_ID");
                String apptTypeReturned = rs.getString("Type");
                Timestamp startDTReturned = rs.getTimestamp("Start");
                Timestamp endDTReturned = rs.getTimestamp("End");
                int customerIdReturned = rs.getInt("Customer_ID");
                startDTReturned.toLocalDateTime();
                endDTReturned.toLocalDateTime();

                monthAppts.add(new Appointment(appointIdReturned, customerIdReturned, apptTitleReturned, apptDescrReturned, apptLocationReturned, apptTypeReturned, apptContactReturned, apptUserIdReturned, startDTReturned.toLocalDateTime(), endDTReturned.toLocalDateTime()));

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return monthAppts;

    }

    /**
     * A method to get the next appointment within 15 minutes of login for a specified user.
     * @param userId
     * @return allAppointments
     */
    public static ObservableList<Appointment> getAppointment15Minute(User userId){
        ObservableList<Appointment> allAppointments = FXCollections.observableArrayList();

        Connection conn = DBConnection.getConnection();

        String selectStatement = "Select * from appointments where Start >= ? AND Start <= ? AND User_ID = ?";
        try {
            Query.setPreparedStatement(conn, selectStatement);


            PreparedStatement statement = Query.getPreparedStatement();
            statement.setTimestamp(1,Timestamp.valueOf(LocalDateTime.now()));
            statement.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now().plusMinutes(15)));
            statement.setInt(3, userId.getUserId());
            statement.executeQuery();

            ResultSet rs = statement.getResultSet();


            while (rs.next()) {
                int appointIdReturned = rs.getInt("Appointment_ID");
                String apptTitleReturned = rs.getString("Title");
                String apptDescrReturned = rs.getString("Description");
                String apptLocationReturned = rs.getString("Location");
                int apptContactReturned = rs.getInt("Contact_ID");
                int apptUserIdReturned = rs.getInt("User_ID");
                String apptTypeReturned = rs.getString("Type");
                Timestamp startDTReturned = rs.getTimestamp("Start");
                Timestamp endDTReturned = rs.getTimestamp("End");
                int customerIdReturned = rs.getInt("Customer_ID");
                startDTReturned.toLocalDateTime();
                endDTReturned.toLocalDateTime();

                allAppointments.add(new Appointment(appointIdReturned, customerIdReturned, apptTitleReturned, apptDescrReturned, apptLocationReturned, apptTypeReturned, apptContactReturned, apptUserIdReturned, startDTReturned.toLocalDateTime(), endDTReturned.toLocalDateTime()));

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return allAppointments;

    }

    /**
     * A method to get appointments by customer ID.
     * @param customer
     * @return allAppointments
     */
    public static ObservableList<Appointment> getAppointmentByCustomer(Customer customer){
        ObservableList<Appointment> allAppointments = FXCollections.observableArrayList();

        Connection conn = DBConnection.getConnection();

        String selectStatement = "SELECT * FROM appointments where Customer_ID = ?";
        try {
            Query.setPreparedStatement(conn, selectStatement);


            PreparedStatement statement = Query.getPreparedStatement();
            statement.setInt(1, customer.getCustomerId());
            statement.executeQuery();

            ResultSet rs = statement.getResultSet();


            while (rs.next()) {
                int appointIdReturned = rs.getInt("Appointment_ID");
                String apptTitleReturned = rs.getString("Title");
                String apptDescrReturned = rs.getString("Description");
                String apptLocationReturned = rs.getString("Location");
                int apptContactReturned = rs.getInt("Contact_ID");
                int apptUserIdReturned = rs.getInt("User_ID");
                String apptTypeReturned = rs.getString("Type");
                Timestamp startDTReturned = rs.getTimestamp("Start");
                Timestamp endDTReturned = rs.getTimestamp("End");
                int customerIdReturned = rs.getInt("Customer_ID");
                startDTReturned.toLocalDateTime();
                endDTReturned.toLocalDateTime();

                allAppointments.add(new Appointment(appointIdReturned, customerIdReturned, apptTitleReturned, apptDescrReturned, apptLocationReturned, apptTypeReturned, apptContactReturned, apptUserIdReturned, startDTReturned.toLocalDateTime(), endDTReturned.toLocalDateTime()));

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return allAppointments;

    }

    }






























