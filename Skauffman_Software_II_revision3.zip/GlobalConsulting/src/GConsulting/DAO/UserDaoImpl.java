package GConsulting.DAO;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Country;
import model.Customer;
import model.User;
import utils.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * This is the User DAO Implementation Class.
 * @author Susan Kauffman
 */
public class UserDaoImpl {
    public static ObservableList<User> userIdList = FXCollections.observableArrayList();

    /**
     * A method to get information for select user by username.
     * @author Susan Kauffman
     */
    public static User getUser(String userName) throws SQLException, Exception{
        Connection conn = DBConnection.getConnection();

        String selectStatement = "SELECT * FROM users WHERE User_Name = '" + userName + "'";
        Query.setPreparedStatement(conn, selectStatement);

        PreparedStatement statement = Query.getPreparedStatement();
        statement.execute();

        ResultSet rs = statement.getResultSet();

        while(rs.next()) {
            int userIdReturned = rs.getInt("User_ID");
            String userNameReturned = rs.getString("User_Name");
            String userPasswordReturned = rs.getString("Password");

            User newUser = new User(userIdReturned,userNameReturned, userPasswordReturned, null, null, null, null);
            return newUser;
        }
    return null;
    }



    /**
     * A method get all users from the database.
     * @author Susan Kauffman
     */
    public static ObservableList<User> getAllUsers(){
        ObservableList<User> allUsers = FXCollections.observableArrayList();

        Connection conn = DBConnection.getConnection();
        String selectStatement ="SELECT * FROM users";
        try {
            Query.setPreparedStatement(conn, selectStatement);


            PreparedStatement statement = Query.getPreparedStatement();
            statement.executeQuery();

            ResultSet rs = statement.getResultSet();


            while (rs.next()) {
                int userID = rs.getInt("User_ID");
                String userName = rs.getString("User_Name");


                allUsers.add(new User(userID, userName, null, null, null, null, null));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return allUsers;

    }
    /**
     * A method to get userID and username from users table in database.
     * @author Susan Kauffman
     */
    public static ObservableList<User> getUserId(){
        ObservableList<User> allUserId = FXCollections.observableArrayList();

        Connection conn = DBConnection.getConnection();
        String selectStatement ="SELECT User_ID, User_Name FROM users";
        try {
            Query.setPreparedStatement(conn, selectStatement);


            PreparedStatement statement = Query.getPreparedStatement();
            statement.executeQuery();

            ResultSet rs = statement.getResultSet();


            while (rs.next()) {
                int userID = rs.getInt("User_ID");
                String userName = rs.getString("User_Name");



                allUserId.add(new User(userID, userName, null, null, null, null, null));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return allUserId;

    }
    }
