package GConsulting.DAO;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.FirstLevelDivision;
import utils.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * This is the First Level Division DAO Implementation Class.
 * @author Susan Kauffman
 */
public class FirstLevelDaoImpl {
    public static ObservableList<FirstLevelDivision> divisionsList = FXCollections.observableArrayList();
    public static ObservableList<FirstLevelDivision> filteredDivisionList = FXCollections.observableArrayList();

    /**
     * A method to select all information from the first level division table in the database.
     */
    public static void selectDivisions(){

        Connection conn = DBConnection.getConnection();

        String selectStatement = "SELECT * FROM first_level_divisions";

        try {
            Query.setPreparedStatement(conn, selectStatement);


            PreparedStatement statement = Query.getPreparedStatement();
            statement.executeQuery();

            ResultSet rs = statement.getResultSet();


            while (rs.next()) {
                int countryIdReturned = rs.getInt("COUNTRY_ID");
                int divisionIDReturned = rs.getInt("Division_ID");
                String divisionNameReturned = rs.getString("Division");
                divisionsList.add(new FirstLevelDivision(countryIdReturned, divisionIDReturned, divisionNameReturned));

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


    }


}




