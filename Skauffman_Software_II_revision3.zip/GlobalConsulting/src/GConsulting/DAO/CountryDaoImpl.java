package GConsulting.DAO;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Country;

import utils.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * This is the Country DAO Implementation Class.
 * @author Susan Kauffman
 */
public class CountryDaoImpl {

   public static ObservableList<Country> countryList = FXCollections.observableArrayList();

    /**
     * A method to get country and country ID from the database.
     */
    public static void selectCountry()  {

        Connection conn = DBConnection.getConnection();

        String selectStatement = "SELECT Country_ID, Country FROM countries";
        try {
            Query.setPreparedStatement(conn, selectStatement);


            PreparedStatement statement = Query.getPreparedStatement();
            statement.executeQuery();

            ResultSet rs = statement.getResultSet();


            while (rs.next()) {
                int countryIdReturned = rs.getInt("Country_ID");
                String countryNameReturned = rs.getString("Country");
                countryList.add(new Country(countryIdReturned, countryNameReturned));

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


    }
}