package GConsulting.DAO;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Report;
import utils.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * This is the Report DAO Implementation Class.
 * @author Susan Kauffman
 */
public class ReportDaoImpl {

    /**
     * A method to get monthly appointments by Type of appointment.
     * This information will populate in the Reports section of the main appointment screen.
     * @author Susan Kauffman
     */
    public static Report getReportData(String month, String type) throws SQLException {
        Connection conn = DBConnection.getConnection();

        String selectStatement = "SELECT COUNT(*) AS totalCount FROM appointments WHERE monthName(Start) = ? AND Type = ?";

        Query.setPreparedStatement(conn, selectStatement);
        PreparedStatement statement = Query.getPreparedStatement();
        statement.setString(1, month);
        statement.setString(2, type);
        statement.executeQuery();

        ResultSet rs = statement.getResultSet();

        rs.next();
        int countReturned = rs.getInt("totalCount");

        Report reportData = new Report(countReturned, type, month);
        return reportData;



    }
}