package GConsulting.DAO;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Customer;
import model.User;
import utils.DBConnection;

import java.sql.*;
import java.time.LocalDateTime;

/**
 * This is the Customer DAO Implementation Class.
 * @author Susan Kauffman
 */
public class CustomerDaoImpl {

    /**
     * A method to add a new customer into the database.
     * @param customer
     * @throws SQLException
     */
    public void newCustomer(Customer customer) throws SQLException {
        Connection conn = DBConnection.getConnection();
        String insertStatement = "INSERT INTO customers(Customer_Name, Address, Postal_Code, Phone, Division_ID) VALUES (?,?,?,?,?)";
        Query.setPreparedStatement(conn, insertStatement);
        PreparedStatement ps = Query.getPreparedStatement();

        ps.setString(1, customer.getCustomerName());
        ps.setString(2, customer.getCustomerAddress());
        ps.setString(3, customer.getCustomerPostalCode());
        ps.setString(4, customer.getCustomerPhone());
        ps.setInt(5, customer.getDivisionId());

        ps.execute();

    }


    /**
     * A method to update a specified customer's information in the database.
     * @param customer
     * @throws SQLException
     */
    public void updateCustomer(Customer customer) throws SQLException {
        Connection conn = DBConnection.getConnection();
        String updateStatement = "UPDATE customers SET Customer_Name = ?, Address = ?, Postal_Code = ?, Phone = ?, Division_ID = ?  WHERE Customer_ID = ?;";
        Query.setPreparedStatement(conn, updateStatement);
        PreparedStatement ps = Query.getPreparedStatement();

        ps.setString(1, customer.getCustomerName());
        ps.setString(2, customer.getCustomerAddress());
        ps.setString(3, customer.getCustomerPostalCode());
        ps.setString(4, customer.getCustomerPhone());
        ps.setInt(5, customer.getDivisionId());
        ps.setInt(6,customer.getCustomerId());

        ps.executeUpdate();
    }

    /**
     * A method to get all customer and their associated city and state.
     * @return allCustomers
     */
    public static ObservableList<Customer> getAllCustomers() {
        ObservableList<Customer> allCustomers = FXCollections.observableArrayList();

        Connection conn = DBConnection.getConnection();

        String selectStatement = "SELECT customers.Customer_ID, customers.Customer_Name, customers.Address, customers.Postal_Code, " +
                "customers.Phone, customers.Division_ID, first_level_divisions.Division, countries.Country, countries.Country_ID\n" +
                "FROM customers\n" +
                "Left JOIN first_level_divisions ON customers.Division_ID = first_level_divisions.Division_ID\n" +
                "Left join countries ON first_level_divisions.COUNTRY_ID = countries.Country_ID;";
        try {
            Query.setPreparedStatement(conn, selectStatement);


            PreparedStatement statement = Query.getPreparedStatement();
            statement.executeQuery();

            ResultSet rs = statement.getResultSet();


            while (rs.next()) {
                int customerIdReturned = rs.getInt("Customer_ID");
                String customerNameReturned = rs.getString("Customer_Name");
                String customerAddressReturned = rs.getString("Address");
                String postalCodeReturned = rs.getString("Postal_Code");
                String phoneReturned = rs.getString("Phone");
                int divisionId = rs.getInt("Division_ID");
                String division = rs.getString("Division");
                String countryName = rs.getString("Country");
                int countryId = rs.getInt("Country_ID");

                allCustomers.add(new Customer(customerIdReturned, customerNameReturned, customerAddressReturned, postalCodeReturned, phoneReturned, divisionId, division, countryName, countryId));

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return allCustomers;

    }

    /**
     * A method to select customers by customer ID.
     * @param custId
     * @return customer
     * @throws SQLException
     * @throws Exception
     */
    public static Customer getCustomer(Customer custId) throws SQLException, Exception{
        Connection conn = DBConnection.getConnection();

        String selectStatement = "SELECT customers.Customer_ID, customers.Customer_Name, customers.Address, customers.Postal_Code, " +
                "customers.Phone, customers.Division_ID, first_level_divisions.Division, countries.Country, countries.Country_ID\n" +
                "FROM customers\n" +
                "Left JOIN first_level_divisions ON customers.Division_ID = first_level_divisions.Division_ID\n" +
                "Left join countries ON first_level_divisions.COUNTRY_ID = countries.Country_ID Where Customer_ID = ?;";
        Query.setPreparedStatement(conn, selectStatement);

        PreparedStatement statement = Query.getPreparedStatement();
        statement.setInt(1, custId.getCustomerId());
        statement.execute();

        ResultSet rs = statement.getResultSet();

        while (rs.next()) {
            int customerIdReturned = rs.getInt("Customer_ID");
            String customerNameReturned = rs.getString("Customer_Name");
            String customerAddressReturned = rs.getString("Address");
            String postalCodeReturned = rs.getString("Postal_Code");
            String phoneReturned = rs.getString("Phone");
            int divisionId = rs.getInt("Division_ID");
            String division = rs.getString("Division");
            String countryName = rs.getString("Country");
            int countryId = rs.getInt("Country_ID");

            Customer customer = new Customer(customerIdReturned, customerNameReturned, customerAddressReturned, postalCodeReturned, phoneReturned, divisionId, division, countryName, countryId);
            return customer;

        }
        return null;
    }

    /**
     * A method to delete a customer from the database.
     * @param customer
     * @throws SQLException
     */
    public void deleteCustomer (Customer customer) throws SQLException {
        Connection conn = DBConnection.getConnection();
        String deleteStatementA = "DELETE from appointments WHERE Customer_ID = ?";
        Query.setPreparedStatement(conn, deleteStatementA);
        PreparedStatement psA = Query.getPreparedStatement();
        psA.setInt(1,customer.getCustomerId());
        psA.execute();
        String deleteStatement = "DELETE from customers WHERE Customer_ID = ?";
        Query.setPreparedStatement(conn, deleteStatement);
        PreparedStatement ps = Query.getPreparedStatement();
        ps.setInt(1,customer.getCustomerId());
        ps.execute();



    }



}
