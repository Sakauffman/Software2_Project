package GConsulting.DAO;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Contact;
import model.User;
import utils.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


/**
 * This is the Contact DAO Implementation Class.
 * @author Susan Kauffman
 */
public class ContactDaoImpl {

    /**
     * A method to get all contacts from the database.
     * @return allContacts
     */
    public static ObservableList<Contact> getAllContacts(){
        ObservableList<Contact> allContacts = FXCollections.observableArrayList();

        Connection conn = DBConnection.getConnection();
        String selectStatement ="SELECT * FROM contacts";
        try {
            Query.setPreparedStatement(conn, selectStatement);


            PreparedStatement statement = Query.getPreparedStatement();
            statement.executeQuery();

            ResultSet rs = statement.getResultSet();


            while (rs.next()) {
                int contactId = rs.getInt("Contact_ID");
                String contactName = rs.getString("Contact_Name");


                allContacts.add(new Contact(contactId, contactName));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return allContacts;

    }
    /**
     * A method to get contacts by contact ID.
     * @param contactId
     * @throws Exception
     */
    public static Contact getContactId(int contactId) throws SQLException, Exception{
        Connection conn = DBConnection.getConnection();

        String selectStatement = "SELECT * FROM contacts WHERE Contact_ID  = '" + contactId + "'";
        Query.setPreparedStatement(conn, selectStatement);

        PreparedStatement statement = Query.getPreparedStatement();
        statement.execute();

        ResultSet rs = statement.getResultSet();

        while(rs.next()) {
            int contactIdReturned = rs.getInt("Contact_ID");
            String contactNameReturned = rs.getString("Contact_Name");


            Contact newContact = new Contact(contactIdReturned, contactNameReturned);
            return newContact;
        }
        return null;
    }


}
