Global Consulting Scheduling Application version 1.0 - 07/08/2021
Purpose:
To provide an easy-to-use environment for the scheduling needs of Global Consulting, Inc.

Author:
Susan Kauffman
Contact Information:
Email: skauff1@wgu.edu

IDE: Intellij IDEA v. 2020.3.1 (Community Edition).
JDK: Java SE 11.0.4
JavaFX version: JavaFX SDK 11.0.2
MySQL Java version: 8.0.21

How to run:
LOGIN:
The application requires that the user be assigned a username and password by the database administrator.  Once this is obtained the user may login via the login screen.

Appointment Main Menu:
*The Appointment tableview will show current appointment by ALL, WEEKLY, or MONTHLY.  The user may create a new appointment, update an appointment or delete an appointment.
*The appointments are shown in the users local time.
*The customer tableview will show all customers in the database for Global Consulting.  The user may create a new customer, update a customer's information or delete a customer.
*Please be aware when deleting a customer, this will also delete the appointments associated with that customer.
    REPORTS:
    There are three types of reports available for use:
    1. The type of appointments by month - this will give a total number of appointments of a certain type of appointment for the chosen month.
    2. The list of appointments by contact - this will display all appointments for a selected contact.
    3. Total number of customers by country - this will allow the user to see the total number of customers in a chosen country.

Language:
The languages available are French and English and will change based on the setting of the user's operating system.



