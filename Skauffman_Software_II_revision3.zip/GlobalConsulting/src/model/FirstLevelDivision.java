package model;
/**
 * This is the FirstLevelDivision class.
 * @author Susan Kauffman
 */
public class FirstLevelDivision {
    private int countryID;
    private int FLDId;
    private String FLDName;

    /**
     * Constructor for the FirstLevelDivision class.
     * @param countryID
     * @param FLDId
     * @param FLDName
     */
    public FirstLevelDivision (int countryID, int FLDId, String FLDName){
        this.countryID = countryID;
        this.FLDName = FLDName;
        this.FLDId = FLDId;

    }

    /**
     * Getter for the Country Id.
     * @return returns the countryID
     */
    public int getCountryID() {

        return countryID;
    }
    /**
     * Setter of the country Id.
     * @param countryID
     */
    public void setCountryID(int countryID) {

        this.countryID = countryID;
    }
    /**
     * Getter for the First Level Division Id.
     * @return returns the FLDId
     */
    public int getFLDId() {

        return FLDId;
    }
    /**
     * Setter of the First Level Division Id.
     * @param FLDId
     */
    public void setFLDId(int FLDId) {

        this.FLDId = FLDId;
    }

    /**
     * Getter for the First Level Division name.
     * @return returns the FLDName
     */
    public String getFLDName() {

        return FLDName;
    }
    /**
     * Setter of the First Level Division name.
     * @param FLDName
     */
    public void setFLDName(String FLDName) {

        this.FLDName = FLDName;
    }


    /**
     * Method to return First Level Division Id to String.
     * @return returns FLDName.
     */
    public String toString(){

        return FLDName;
    }
}
