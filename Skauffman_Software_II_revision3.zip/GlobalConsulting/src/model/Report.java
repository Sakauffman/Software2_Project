package model;
/**
 * This is the Report class.
 * @author Susan Kauffman
 */
public class Report {
    private int count;
    private String type;
    private String month;

    /**
     * Constructor for the Report class.
     * @param count
     * @param type
     * @param month
     */
    public Report(int count, String type, String month){
        this.count = count;
        this.type = type;
        this.month = month;

    }

    /**
     * Getter for the appointment count.
     * @return count
     */
    public int getCount() {

        return count;
    }

    /**
     * Setter of the appointment count.
     * @param count
     */
    public void setCount(int count) {

        this.count = count;
    }

    /**
     * Getter for the appointment type.
     * @return type
     */
    public String getType() {

        return type;
    }
    /**
     * Setter of the appointment type.
     * @param type
     */
    public void setType(String type) {

        this.type = type;
    }

    /**
     * Getter for the appointment month.
     * @return month
     */
    public String getMonth() {

        return month;
    }
    /**
     * Setter of the appointment month.
     * @param month
     */
    public void setMonth(String month) {

        this.month = month;
    }
}
