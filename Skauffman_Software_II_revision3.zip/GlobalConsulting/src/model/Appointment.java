package model;

import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Calendar;

/**
 * This is the Appointment class.
 * @author Susan Kauffman
 */

public class Appointment {
    private int appointmentId;
    private int customerId;
    private String appointmentTitle;
    private String appointmentDescription;
    private String appointmentLocation;
    private String appointmentType;
    private int appointmentContactId;
    private int appointmentUserId;
    private LocalDateTime appointmentStartTime;
    private LocalDateTime appointmentEndTime;


    /**
     * Constructor for the Appointment Class.
     * @param appointmentId
     * @param customerId
     * @param appointmentTitle
     * @param appointmentDescription
     * @param appointmentLocation
     * @param appointmentType
     * @param appointmentContactId
     * @param appointmentUserId
     * @param appointmentStartTime
     * @param appointmentEndTime
     */
    public Appointment(int appointmentId, int customerId, String appointmentTitle, String appointmentDescription, String appointmentLocation, String appointmentType,int appointmentContactId, int appointmentUserId, LocalDateTime appointmentStartTime, LocalDateTime appointmentEndTime) {
        this.appointmentId = appointmentId;
        this.customerId = customerId;
        this.appointmentTitle = appointmentTitle;
        this.appointmentDescription = appointmentDescription;
        this.appointmentLocation = appointmentLocation;
        this.appointmentType = appointmentType;
        this.appointmentContactId = appointmentContactId;
        this.appointmentStartTime = appointmentStartTime;
        this.appointmentEndTime = appointmentEndTime;
        this.appointmentUserId = appointmentUserId;


    }
    /**
     * Getter of the id of the appointment user.
     * @return appointmentUserId
     */
    public int getAppointmentUserId() {
        return appointmentUserId;
    }
    /**
     * Setter of the id of the appointment user.
     * @param appointmentUserId
     */
    public void setAppointmentUserId(int appointmentUserId) {
        this.appointmentUserId = appointmentUserId;
    }

    /**
     * Setter of the Start time and Date of the appointment.
     * @param appointmentStartTime
     */
    public void setAppointmentStartTime(LocalDateTime appointmentStartTime) {
        this.appointmentStartTime = appointmentStartTime;
    }

    /**
     * Setter of the appointment end time and date.
     * @param appointmentEndTime
     */
    public void setAppointmentEndTime(LocalDateTime appointmentEndTime) {
        this.appointmentEndTime = appointmentEndTime;
    }
    /**
     * Getter of the id of the customer ID.
     * @return returns the customerId.
     */
    public int getCustomerId() {

        return customerId;
    }

    /**
     * Setter of the customer id.
     * @param customerId
     */
    public void setCustomerId(int customerId) {

        this.customerId = customerId;
    }

    /**
     * Getter of the contact Id for the appointment.
     * @return returns the contact id.
     */
    public int getAppointmentContactId() {

        return appointmentContactId;
    }

    /**
     * Setter of the appointment contact Id.
     * @param appointmentContactId
     */
    public void setAppointmentContactId(int appointmentContactId) {

        this.appointmentContactId = appointmentContactId;
    }

    /**
     * Getter of the appointment id.
     * @return returns the appointment id.
     */
    public int getAppointmentId() {

        return appointmentId;
    }

    /**
     * Setter of the appointment id.
     * @param appointmentId
     */
    public void setAppointmentId(int appointmentId) {

        this.appointmentId = appointmentId;
    }

    /**
     * Getter of the appointment title.
     * @return returns the title.
     */
    public String getAppointmentTitle() {

        return appointmentTitle;
    }

    /**
     * Setter of the appointment title.
     * @param appointmentTitle
     */
    public void setAppointmentTitle(String appointmentTitle) {

        this.appointmentTitle = appointmentTitle;
    }

    /**
     * Getter of the appointment description.
     * @return returns the appointment description.
     */

    public String getAppointmentDescription() {

        return appointmentDescription;
    }

    /**
     * Setter of the appointment description.
     * @param appointmentDescription
     */
    public void setAppointmentDescription(String appointmentDescription) {
        this.appointmentDescription = appointmentDescription;
    }
    /**
     * Getter of the appointment location.
     * @return returns the appointment location.
     */
    public String getAppointmentLocation() {

        return appointmentLocation;
    }

    /**
     * Setter of the appointment location.
     * @param appointmentLocation
     */
    public void setAppointmentLocation(String appointmentLocation) {

        this.appointmentLocation = appointmentLocation;
    }
    /**
     * Getter of the appointment type.
     * @return returns the appointment type.
     */
    public String getAppointmentType() {

        return appointmentType;
    }

    /**
     * Setter of the appointment type.
     * @param appointmentType
     */
    public void setAppointmentType(String appointmentType) {

        this.appointmentType = appointmentType;
    }

    /**
     * Getter of the appointment start time and date.
     * @return returns the appointment start time and date.
     */
    public LocalDateTime getAppointmentStartTime() {

        return appointmentStartTime;
    }

    /**
     * Getter of the appointment end time and date.
     * @return returns the appointment end time and date.
     */
    public LocalDateTime getAppointmentEndTime() {

        return appointmentEndTime;
    }
    /**
     * Method to return userID value as String Name.
     * @return String.ValueOf(appointmentID)
     */
    public String toString(){

        return String.valueOf(appointmentUserId);
    }
    /**
     * A method to validate the appointment information.
     */
    public static String isDataValid(Customer custId, String apptTitle, String apptDescr, String apptLoc, String apptType, Contact apptContactId, User apptUserId, String exceptionMessage) {

        if(custId == null) {
            exceptionMessage = exceptionMessage + ("Please select a customer.\n");

        }

        if(apptTitle.isEmpty()) {
            exceptionMessage = exceptionMessage + ("Title cannot be blank.\n");
        }

        if(apptDescr.isEmpty()) {
            exceptionMessage = exceptionMessage + ("Description cannot be blank.\n");
        }

        if(apptLoc.isEmpty()) {
            exceptionMessage = exceptionMessage + ("Please select a location.\n");
        }

        if(apptType == null){
            exceptionMessage = exceptionMessage + ("Please select and appointment Type.\n");
        }

        //if(startHour.isEmpty()){
        //    exceptionMessage = exceptionMessage +("Please select a starting hour.\n");
        //}

        //if(startMin.isEmpty()){
         //   exceptionMessage = exceptionMessage +("Please select starting minutes.\n");
       // }

        //if(endHour.isEmpty()){
        //    exceptionMessage = exceptionMessage +("Please select an ending hour.\n");
        //}

        //if(endMin.isEmpty()){
         //   exceptionMessage = exceptionMessage +("Please select ending minutes.\n");
        //}

        if(apptContactId == null){
            exceptionMessage = exceptionMessage +("Please select a Contact for the appointment.\n");
        }

        if(apptUserId == null){
            exceptionMessage = exceptionMessage + ("Please select a User for the appoinment.\n");
        }
        return exceptionMessage;
    }

}
