package model;

import GConsulting.DAO.CountryDaoImpl;
import javafx.scene.control.ComboBox;

import java.time.LocalDateTime;
/**
 * This is the Country class.
 * @author Susan Kauffman
 */
public class Country {

    private int countryId;
    private String countryName;

    /**
     * This is the constructor for the Country class.
     * @param countryId
     * @param countryName
     */
    public Country(int countryId, String countryName){
        this.countryId = countryId;
        this.countryName = countryName;

    }
    /**
     * Constructor for the Country class.
     */
    public Country(){
        this.countryId = 0;
        this.countryName = "";

    }
    /**
     * Getter of the country Id.
     * @return returns the countryId
     */
    public int getCountryId() {

        return countryId;
    }
    /**
     * Setter of the country Id.
     * @param countryId
     */
    public void setCountryId(int countryId) {

        this.countryId = countryId;
    }
    /**
     * Getter of the country name.
     * @return returns the countryName
     */
    public String getCountryName() {

        return countryName;
    }
    /**
     * Setter of the country name.
     * @param countryName
     */
    public void setCountryName(String countryName) {

        this.countryName = countryName;
    }
    /**
     * Method to return countryId as a String.
     * @return returns countryName.
     */
    public String toString(){

        return countryName;
    }

}

