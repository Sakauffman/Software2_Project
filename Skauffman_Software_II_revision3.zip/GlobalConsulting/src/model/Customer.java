package model;

import java.time.LocalDateTime;
import java.util.Calendar;
/**
 * This is the Customer class.
 * @author Susan Kauffman
 */
public class Customer {
    private int customerId;
    private String customerName;
    private String customerAddress;
    private String customerPostalCode;
    private String customerPhone;
    private int divisionId;
    private String division;
    private String country;
    private int countryId;

    /**
     * Constructor for the Customer class.
     * @param customerId
     * @param customerName
     * @param customerAddress
     * @param customerPostalCode
     * @param customerPhone
     * @param divisionId
     * @param division
     * @param country
     * @param countryId
     */
    public Customer(int customerId, String customerName, String customerAddress, String customerPostalCode, String customerPhone,int divisionId, String division, String country, int countryId) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.customerAddress = customerAddress;
        this.customerPostalCode = customerPostalCode;
        this.customerPhone = customerPhone;
        this.divisionId = divisionId;
        this.division = division;
        this.country = country;
        this. countryId = countryId;
    }

    /**
     * Getter of the country name.
     * @return returns the country
     */
    public String getCountry() {

        return country;
    }

    /**
     * Setter of the country name.
     * @param country
     */
    public void setCountry(String country) {

        this.country = country;
    }

    /**
     * Getter of the country Id.
     * @return returns the countryId
     */
    public int getCountryId() {

        return countryId;
    }

    /**
     * Setter of the country Id.
     * @param countryId
     */
    public void setCountryId(int countryId) {

        this.countryId = countryId;
    }

    /**
     * Getter of the division name.
     * @return returns the division
     */
    public String getDivision() {

        return division;
    }

    /**
     * Setter of the division name.
     * @param division
     */
    public void setDivision(String division) {

        this.division = division;
    }

    /**
     * Getter of the Division Id.
     * @return returns the divisionId
     */
    public int getDivisionId() {

        return divisionId;
    }
    /**
     * Setter of the division Id.
     * @param divisionId
     */
    public void setDivisionId(int divisionId) {

        this.divisionId = divisionId;
    }
    /**
     * Getter of the customer Id.
     * @return returns the customerId
     */
    public int getCustomerId() {

        return customerId;
    }

    /**
     * Setter of the customer Id.
     * @param customerId
     */
    public void setCustomerId(int customerId) {

        this.customerId = customerId;
    }

    /**
     * Getter of the customer name.
     * @return returns the customerName
     */
    public String getCustomerName() {

        return customerName;
    }

    /**
     * Setter of the customer name.
     * @param customerName
     */
    public void setCustomerName(String customerName) {

        this.customerName = customerName;
    }
    /**
     * Getter of the customer address.
     * @return returns the customerAddress
     */
    public String getCustomerAddress() {

        return customerAddress;
    }
    /**
     * Setter of the customer address.
     * @param customerAddress
     */
    public void setCustomerAddress(String customerAddress) {

        this.customerAddress = customerAddress;
    }

    /**
     * Getter of the customer postal code.
     * @return returns the customerPostalCode
     */
    public String getCustomerPostalCode() {

        return customerPostalCode;
    }
    /**
     * Setter of the customer postal code.
     * @param customerPostalCode
     */
    public void setCustomerPostalCode(String customerPostalCode) {

        this.customerPostalCode = customerPostalCode;
    }

    /**
     * Getter of the customer phone number.
     * @return returns the customerPhone
     */
    public String getCustomerPhone() {
        return customerPhone;
    }

    /**
     * Setter of the customer phone number.
     * @param customerPhone
     */
    public void setCustomerPhone(String customerPhone) {

        this.customerPhone = customerPhone;
    }
    /**
     * Method to return customerId value as ID number and String Name.
     * @return returns customerId and customerName.
     */
    public String toString(){

        return "[" + String.valueOf(customerId) + "] "+ customerName;
    }

    /**
     * A method to validate the customer information.
     */
    public static String isDataValid(String name, String address, String postalCode, String phone, String division, String countryName, String exceptionMessage) {


        if(name.isEmpty()){
            exceptionMessage = exceptionMessage + ("Please enter the customer name.\n");
        }

        if(address.isEmpty()){
            exceptionMessage = exceptionMessage + ("Please enter the customer street address.\n");
        }

        if(postalCode.isEmpty()){
            exceptionMessage = exceptionMessage + ("Please enter the customer postal code.\n");
        }

        if(phone.isEmpty()){
            exceptionMessage = exceptionMessage + ("Please enter the customer phone number.\n");
        }

        if(division == null){
            exceptionMessage = exceptionMessage + ("Please Select a state or province.\n");
        }

        if(countryName == null){
            exceptionMessage = exceptionMessage + ("Please Select a Country.\n");
        }

        return exceptionMessage;
    }
}
