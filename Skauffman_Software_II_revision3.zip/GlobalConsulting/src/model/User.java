package model;

import java.time.LocalDateTime;
import java.util.Calendar;

/**
 * This is the User class.
 * @author Susan Kauffman
 */
public class User {
    private int userId;
    private String userName;
    private String password;
    private LocalDateTime createDate;
    private String createdBy;
    private LocalDateTime lastUpdate;
    private String lastUpdatedBy;

    /**
     * Constructor for the User Class.
     * @param userId
     * @param userName
     * @param password
     * @param createDate
     * @param createdBy
     * @param lastUpdate
     * @param lastUpdatedBy
     */
    public User(int userId, String userName, String password, LocalDateTime createDate, String createdBy, LocalDateTime lastUpdate, String lastUpdatedBy){
        this.userId = userId;
        this.userName = userName;
        this.password = password;
        this.createDate = createDate;
        this.createdBy = createdBy;
        this.lastUpdate = lastUpdate;
        this.lastUpdatedBy = lastUpdatedBy;

    }

    /**
     * Getter for the user Id.
     * @return userId
     */
    public int getUserId() {
        return userId;
    }

    /**
     * Setter for the User Id.
     * @param userId
     */
    public void setUserId(int userId) {
        this.userId = userId;
    }
    /**
     * Getter for the user name.
     * @return userName
     */
    public String getUserName() {

        return userName;
    }
    /**
     * Setter for the user name.
     * @param userName
     */
    public void setUserName(String userName) {

        this.userName = userName;
    }
    /**
     * Getter for the user password.
     * @return password
     */
    public String getPassword() {

        return password;
    }
    /**
     * Setter for the user password.
     * @param password
     */
    public void setPassword(String password) {

        this.password = password;
    }

    /**
     * A method to return the user name as a String and user Id.
     * @return userId and userName
     */
    public String toString(){

        return "[" + String.valueOf(userId) + "] "+ userName;
    }




}
