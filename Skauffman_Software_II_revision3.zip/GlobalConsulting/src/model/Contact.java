package model;

/**
 * This is the Contact class.
 * @author Susan Kauffman
 */
public class Contact {

    private int contactId;
    private String contactName;

    /**
     * This is the constructor for the Contact class.
     * @param contactId
     * @param contactName
     */

    public Contact(int contactId, String contactName) {
        this.contactId = contactId;
        this.contactName = contactName;
    }

    /**
     * Getter of the contact Id.
     * @return returns the contactId
     */
    public int getContactId() {

        return contactId;
    }

    /**
     * Setter of the contact Id.
     * @param contactId
     */
    public void setContactId(int contactId) {

        this.contactId = contactId;
    }

    /**
     * Getter of the contact name.
     * @return returns the contactName
     */
    public String getContactName() {

        return contactName;
    }

    /**
     * Setter of the contact name.
     * @param contactName
     */

    public void setContactName(String contactName) {

        this.contactName = contactName;
    }

    /**
     * Method to return contactID value as ID number and String Name.
     * @return returns contactId and contactName.
     */
    public String toString(){

        return "[" + String.valueOf(contactId) + "] "+ contactName;
    }
}
