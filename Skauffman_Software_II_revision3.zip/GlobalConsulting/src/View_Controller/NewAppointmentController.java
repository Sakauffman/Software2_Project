package View_Controller;

import GConsulting.DAO.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.*;
import java.time.chrono.ChronoLocalDateTime;
import java.time.chrono.ChronoZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Optional;
import java.util.ResourceBundle;

public class NewAppointmentController implements Initializable {


    private String exceptionMessage = new String();
    private AppointmentDaoImpl appointmentDao = new AppointmentDaoImpl();
    @FXML
    private Label newApptApptIdLbl;

    @FXML
    private Label newApptTitleLbl;

    @FXML
    private Label newApptTypeLbl;

    @FXML
    private Label newApptLocationLbl;

    @FXML
    private Label newApptDescrLbl;

    @FXML
    private TextField newApptIdTxtField;

    @FXML
    private ComboBox<Contact> newApptContactComboBox;

    @FXML
    private Label newApptStartTimeLbl;

    @FXML
    private Label newApptStartDateLbl;

    @FXML
    private DatePicker newApptDatePicker;

    @FXML
    private TextField newApptDescrTxtBox;

    @FXML
    private TextField newApptTitleTxtBox;

    @FXML
    private Label newApptCustIdLbl;

    @FXML
    private Label newApptUserIdLbl;

    @FXML
    private Label newApptEndTimeLbl;

    @FXML
    private TextField newApptCustIdTxtField;

    @FXML
    private Button newApptSaveButton;

    @FXML
    private Button newApptCancelNewAppt;

    @FXML
    private ComboBox<String> newApptLocationCombo;

    @FXML
    private ComboBox<String> newApptTypeCombo;

    @FXML
    private ComboBox<String> newApptStartTimeHourCombo;

    @FXML
    private ComboBox<String> newApptEndTimeHourCombo;

    @FXML
    private ComboBox<String> newApptStartTimeMinCombo;

    @FXML
    private ComboBox<String> newApptEndTimeMinCombo;

    @FXML
    private ComboBox<User> newApptUserIdCombo;

    @FXML
    private Label newApptUserIdLbl1;

    @FXML
    private ComboBox<Customer> newApptCustCombo;

    /**
     * This method not used at this time.
     */
    @FXML
    void onActionLoadContacts(ActionEvent event) {

    }
    /**
     * This method not used at this time.
     */
    @FXML
    void onActionLoadLocation(ActionEvent event) {


    }
    /**
     * This method not used at this time.
     */
    @FXML
    void onActionLoadStartHours(ActionEvent event) {

    }
    /**
     * This method not used at this time.
     */
    @FXML
    void onActionLoadStartMins(ActionEvent event) {

    }
    /**
     * This method not used at this time.
     */
    @FXML
    void onActionLoadEndHours(ActionEvent event) {

    }
    /**
     * This method not used at this time.
     */
    @FXML
    void onActionLoadEndMins(ActionEvent event) {

    }

    /**
     * This method not used at this time.
     */
    @FXML
    void onActionLoadType(ActionEvent event) {

    }
    /**
     * This method not used at this time.
     */
    @FXML
    void onActionLoadUsers(ActionEvent event) {


    }

    /**
     * Saves the new appointment. Validations are performed to verify all needed
     * information is entered before saving appointment.
     * @param event
     * @throws SQLException
     * @throws IOException
     */
    @FXML
    void onActionSaveNewAppt(ActionEvent event) throws Exception {

        boolean overlap = false;

        Customer customerId = newApptCustCombo.getValue();
        String title = newApptTitleTxtBox.getText();
        String desc = newApptDescrTxtBox.getText();
        String location = newApptLocationCombo.getValue();
        String type = newApptTypeCombo.getValue();
        LocalDate dateOfAppt = newApptDatePicker.getValue();
        String startHour = newApptStartTimeHourCombo.getValue();
        String startMins = newApptStartTimeMinCombo.getValue();
        String endHour = newApptEndTimeHourCombo.getValue();
        String endMins = newApptEndTimeMinCombo.getValue();
        User userId = newApptUserIdCombo.getValue();
        Contact contactId = newApptContactComboBox.getValue();
        if (dateOfAppt == null || startHour == null || startMins == null || endHour == null || endMins == null) {
            Alert alert3 = new Alert(Alert.AlertType.INFORMATION);
            alert3.setTitle("Appointment cannot be added.");
            alert3.setHeaderText("Error adding appointment.");
            alert3.setContentText("All time and date components must be completed..");
            alert3.showAndWait();
        } else {
            LocalDateTime ldtStart = LocalDateTime.of(dateOfAppt.getYear(), dateOfAppt.getMonthValue(), dateOfAppt.getDayOfMonth(), Integer.parseInt(startHour), Integer.parseInt(startMins));
            LocalDateTime ldtEnd = LocalDateTime.of(dateOfAppt.getYear(), dateOfAppt.getMonthValue(), dateOfAppt.getDayOfMonth(), Integer.parseInt(endHour), Integer.parseInt(endMins));
            //convert ldtEnd and ltdStart and check them against Eastern
            ZonedDateTime zdtStart = ldtStart.atZone(ZoneId.systemDefault());
            ZonedDateTime estStart = zdtStart.withZoneSameInstant(ZoneId.of("America/New_York"));
            estStart.toLocalTime();
            ZonedDateTime zdtEnd = ldtEnd.atZone(ZoneId.systemDefault());
            ZonedDateTime estEnd = zdtEnd.withZoneSameInstant(ZoneId.of("America/New_York"));
            estEnd.toLocalTime();

            exceptionMessage = Appointment.isDataValid(customerId, title, desc, location, type, contactId, userId, exceptionMessage);
            if (exceptionMessage.length() > 0) {
                Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                alert1.setTitle("Appointment cannot be added.");
                alert1.setHeaderText("Error adding appointment");
                alert1.setContentText(exceptionMessage);
                alert1.showAndWait();
                exceptionMessage = "";
            } else if (estStart.isAfter(estEnd) || estEnd.isBefore(estStart)) { //verify end time cannot precede start time
                Alert alert2 = new Alert(Alert.AlertType.INFORMATION);
                alert2.setTitle("Appointment cannot be added.");
                alert2.setHeaderText("Error adding appointment.");
                alert2.setContentText("Appointment end time cannot precede start time.");
                alert2.showAndWait();
            } else if (estStart == null || estEnd == null) {
                Alert alert3 = new Alert(Alert.AlertType.INFORMATION);
                alert3.setTitle("Appointment cannot be added.");
                alert3.setHeaderText("Error adding appointment.");
                alert3.setContentText("All time and date components must be completed..");
                alert3.showAndWait();
            } else if (estStart.toLocalTime().isBefore(LocalTime.of(8,00)) || estEnd.toLocalTime().isAfter(LocalTime.of(21, 45))){
                Alert alert1 = new Alert((Alert.AlertType.ERROR));
                alert1.setTitle("Error");
                alert1.setHeaderText("Start time outside business hours.");
                alert1.setContentText("Please enter times between 8 AM and 9:45 PM EST.");
                alert1.showAndWait();
            } else if (estStart.toLocalTime().isAfter(LocalTime.of(22,00))){
                Alert alert1 = new Alert((Alert.AlertType.ERROR));
                alert1.setTitle("Error");
                alert1.setHeaderText("End time outside business hours.");
                alert1.setContentText("Please enter times between 8:15 AM and 10PM EST.");
                alert1.showAndWait();
            }
            else if (exceptionMessage.length() <= 0) {

                Customer myCustomer = CustomerDaoImpl.getCustomer(customerId);
                ObservableList<Appointment> appts = AppointmentDaoImpl.getAppointmentByCustomer(customerId);
                for (Appointment apptByCust : appts) {
                    assert myCustomer != null;
                    if (myCustomer.getCustomerId() == apptByCust.getCustomerId()) {
                        if(ldtStart.isEqual(apptByCust.getAppointmentStartTime()))
                         overlap = true;
                        else if (ldtStart.isAfter(apptByCust.getAppointmentStartTime()) && ldtStart.isBefore(apptByCust.getAppointmentEndTime()))
                            overlap = true;
                        else if(ldtEnd.isEqual(apptByCust.getAppointmentEndTime()))
                            overlap = true;
                        else if (ldtEnd.isAfter(apptByCust.getAppointmentStartTime()) && ldtEnd.isBefore(apptByCust.getAppointmentEndTime()))
                            overlap = true;
                        else if (ldtStart.isBefore(apptByCust.getAppointmentStartTime()) && ldtEnd.isAfter(apptByCust.getAppointmentStartTime()))
                            overlap = true;
                        if(overlap) {
                            Alert alert = new Alert(Alert.AlertType.ERROR);
                            alert.setTitle("Error");
                            alert.setHeaderText("Customer appointment overlap.");
                            alert.setContentText("Customer already has an appointment during this time period.");
                            alert.showAndWait();
                            break;
                        }
                    }//end if that checks customer ID
                }//end for
                if(!overlap){
                    Appointment appointment = new Appointment(0, customerId.getCustomerId(), title, desc, location, type, contactId.getContactId(), userId.getUserId(), ldtStart, ldtEnd);
                    appointmentDao.setAppointment(appointment);
                    returnMainScreen(event);
                }
            }//end else if





            }
        }



    /**
     * Cancels the action of creating a new appointment.
     * @param event
     * @throws IOException
     */

    @FXML
    void onActionCancelNewAppt(ActionEvent event) throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "This will clear all entered values. Do you want to continue?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {

            returnMainScreen(event);
        }

    }


    /**
     * Initializes the controller class.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<String> locations = FXCollections.observableArrayList ("Board room", "Conference Room", "IT Conference Room");
        newApptLocationCombo.setItems(locations);

        ObservableList<User> getUsers = UserDaoImpl.getUserId();
        newApptUserIdCombo.setItems(getUsers);

        ObservableList<Contact> getContacts = ContactDaoImpl.getAllContacts();
        newApptContactComboBox.setItems(getContacts);

        ObservableList<String> hours = FXCollections.observableArrayList("04", "05", "06", "07", "08", "09", "10", "11","12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23");
        newApptStartTimeHourCombo.setItems(hours);
        newApptEndTimeHourCombo.setItems(hours);

        ObservableList<String> minutes = FXCollections.observableArrayList("00", "15", "30", "45");
        newApptStartTimeMinCombo.setItems(minutes);
        newApptEndTimeMinCombo.setItems(minutes);


        ObservableList<String> types = FXCollections.observableArrayList("Planning Session", "De-Briefing", "Project Wrap-Up");
        newApptTypeCombo.setItems(types);

        ObservableList<Customer> getCustomers = CustomerDaoImpl.getAllCustomers();
        newApptCustCombo.setItems(getCustomers);

    }

    /**
     * Return to Main Menu screen. This method will return the user to the Main
     * menu.
     * @param event
     * @throws IOException
     */
    public void returnMainScreen(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("/View_Controller/appointments.fxml"));

        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

}
