package View_Controller;

import GConsulting.DAO.CountryDaoImpl;
import GConsulting.DAO.CustomerDaoImpl;
import GConsulting.DAO.FirstLevelDaoImpl;
import GConsulting.DAO.Query;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.Appointment;
import model.Country;
import model.Customer;
import model.FirstLevelDivision;
import utils.DBConnection;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * This is the NewCustomerController Class.
 */
public class NewCustomerController implements Initializable {

    private String exceptionMessage = new String();
    private CustomerDaoImpl customerDao = new CustomerDaoImpl();

    @FXML
    private TextField addCustomerIDTxt;

    @FXML
    private Label addCustomerIDLbl;

    @FXML
    private Label addCustomerPCLbl;

    @FXML
    private TextField addCustomerNameTxt;

    @FXML
    private TextField addCustomerAddressTxt;

    @FXML
    private TextField addCustomerPCTxt;

    @FXML
    private TextField addCustomerPhoneTxt;

    @FXML
    private Label addCustomerPhoneLbl;

    @FXML
    private Label addCustomerNameLbl;

    @FXML
    private Label addNewCustomerAddressLbl;

    @FXML
    private Button addNewCustomerSaveButton;

    @FXML
    private Button addNewCustomerCancelButton;

    @FXML
    private ComboBox<Country> countryComboBox;

    @FXML
    private ComboBox<FirstLevelDivision> newCustFLDComboBox;

    @FXML
    private Label newCustCountryLbl;

    @FXML
    private Label newCustFirstDivLbl;


    /**
     * Filters the Country in the combo box to match the First Level Divisions.
     * @param actionEvent
     */
    @FXML
    public void onClickLoadCountry(ActionEvent actionEvent) {
        filterComboBoxes();

    }

    /**
     * Exits the New Customer entry form.
     * This action will not save any entered information.
     * @param event
     * @throws IOException
     */
    @FXML
    void onClickExitToMain(MouseEvent event) throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "This will clear all entered values. Do you want to continue?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            Parent root = FXMLLoader.load(getClass().getResource("/View_Controller/appointments.fxml"));
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }
    }

    /**
     * Saves the New customer information into the database.
     * @param event
     * @throws SQLException
     * @throws IOException
     */
    @FXML
    void onClickSaveNewCustomer(ActionEvent event) throws SQLException, IOException {

        String name = addCustomerNameTxt.getText();
        String phone = addCustomerPhoneTxt.getText();
        String address = addCustomerAddressTxt.getText();
        String postalCode = addCustomerPCTxt.getText();
        int divisionId;
        String division = newCustFLDComboBox.toString();
        String country = countryComboBox.toString();
        int countryId = 0;


        //get division ID
        FirstLevelDivision firstLevelDiv = newCustFLDComboBox.getValue();
        divisionId = firstLevelDiv.getFLDId();

        exceptionMessage = Customer.isDataValid(name, address, postalCode, phone, division, country, exceptionMessage);
        if (exceptionMessage.length() > 0) {
            Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
            alert1.setTitle("Customer cannot be added.");
            alert1.setHeaderText("Error adding customer");
            alert1.setContentText(exceptionMessage);
            alert1.showAndWait();
            exceptionMessage = "";}
            else{
                Customer customer = new Customer(0, name, address, postalCode, phone, divisionId, division, country, countryId);
                customerDao.newCustomer(customer);

                returnMainScreen(event);

            }

    }


    /**
     * Initializes the Controller.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<Country> loadCountry = CountryDaoImpl.countryList;
        countryComboBox.setItems(loadCountry);
        countryComboBox.getSelectionModel().select(0);
        filterComboBoxes();



    }

    /**
     * Performs a filter of the FLD and Country combo boxes.
     */
    public void filterComboBoxes (){
        FirstLevelDaoImpl.filteredDivisionList.clear();

        for(FirstLevelDivision fld : FirstLevelDaoImpl.divisionsList){
            if(fld.getCountryID() == countryComboBox.getSelectionModel().getSelectedItem().getCountryId())
                FirstLevelDaoImpl.filteredDivisionList.add(fld);

        }

        newCustFLDComboBox.setItems(FirstLevelDaoImpl.filteredDivisionList);
        newCustFLDComboBox.getSelectionModel().select(0);
    }

    /**
     * Return to Main Menu screen. This method will return the user to the Main
     * menu.
     * @param event
     * @throws IOException
     */
    public void returnMainScreen(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("/View_Controller/appointments.fxml"));

        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }



}
