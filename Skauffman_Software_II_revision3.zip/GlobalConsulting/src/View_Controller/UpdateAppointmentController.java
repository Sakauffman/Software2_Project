package View_Controller;

import GConsulting.DAO.AppointmentDaoImpl;
import GConsulting.DAO.ContactDaoImpl;
import GConsulting.DAO.CustomerDaoImpl;
import GConsulting.DAO.UserDaoImpl;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Appointment;
import model.Contact;
import model.Customer;
import model.User;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.*;
import java.time.chrono.ChronoLocalDateTime;
import java.time.chrono.ChronoZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * This is the UpdateAppointmentController.
 * @author Susan Kauffman
 */
public class UpdateAppointmentController implements Initializable {

    private String exceptionMessage = new String();

    private Appointment selectedAppointment;

    private AppointmentDaoImpl appointmentDao = new AppointmentDaoImpl();

    @FXML
    private TextField updateApptIdTxtField;

    @FXML
    private ComboBox<Contact> updtApptContactComboBox;

    @FXML
    private DatePicker updtApptDatePicker;

    @FXML
    private TextField updtApptDescrTxtBox;

    @FXML
    private TextField updtApptTitleTxtBox;

    @FXML
    private ComboBox<String> updtApptLocationCombo;

    @FXML
    private ComboBox<String> updtApptTypeCombo;

    @FXML
    private ComboBox<String> updtApptStartTimeHourCombo;

    @FXML
    private ComboBox<String> updtApptEndTimeHourCombo;

    @FXML
    private ComboBox<User> updtApptUserIdCombo;

    @FXML
    private ComboBox<Customer> updtApptCustCombo;

    @FXML
    private ComboBox<String> updtApptStartTimeMinCombo;

    @FXML
    private ComboBox<String> updtApptEndTimeMinCombo;

    /**
     * Cancels the action of updating an appointment.
     * @param event
     * @throws IOException
     */
    @FXML
    void onActionCancelUpdate(ActionEvent event) throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "This will cancel all updates. Do you want to continue?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {

            returnMainScreen(event);
        }


    }
    /**
     * Saves the newly updated appointment information. Validations are included.
     * @param event
     * @throws IOException
     * @throws SQLException
     */
    @FXML
    void onActionSaveUpdatedAppt(ActionEvent event) throws Exception {
        boolean overlap = false;

        int apptId = Integer.parseInt(updateApptIdTxtField.getText());
        Customer customerId = updtApptCustCombo.getValue();
        String title = updtApptTitleTxtBox.getText();
        String desc = updtApptDescrTxtBox.getText();
        String location = updtApptLocationCombo.getValue();
        String type = updtApptTypeCombo.getValue();
        LocalDate date = updtApptDatePicker.getValue();
        String startHour = updtApptStartTimeHourCombo.getValue();
        String startMins = updtApptStartTimeMinCombo.getValue();
        String endHour = updtApptEndTimeHourCombo.getValue();
        String endMins = updtApptEndTimeMinCombo.getValue();
        User userId = updtApptUserIdCombo.getValue();
        Contact contactId = updtApptContactComboBox.getValue();
        LocalDateTime ldtStart = LocalDateTime.of(date.getYear(), date.getMonthValue(), date.getDayOfMonth(), Integer.parseInt(startHour), Integer.parseInt(startMins));
        LocalDateTime ldtEnd = LocalDateTime.of(date.getYear(), date.getMonthValue(), date.getDayOfMonth(), Integer.parseInt(endHour), Integer.parseInt(endMins));
        ZonedDateTime zdtStart = ldtStart.atZone(ZoneId.systemDefault());
        ZonedDateTime estStart = zdtStart.withZoneSameInstant(ZoneId.of("America/New_York"));
        estStart.toLocalTime();
        ZonedDateTime zdtEnd = ldtEnd.atZone(ZoneId.systemDefault());
        ZonedDateTime estEnd = zdtEnd.withZoneSameInstant(ZoneId.of("America/New_York"));
        estEnd.toLocalTime();

        exceptionMessage = Appointment.isDataValid(customerId, title, desc, location, type, contactId, userId, exceptionMessage);
        if (exceptionMessage.length() > 0) {
            Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
            alert1.setTitle("Appointment cannot be added.");
            alert1.setHeaderText("Error adding appointment");
            alert1.setContentText(exceptionMessage);
            alert1.showAndWait();
            exceptionMessage = "";
        } else if (estStart.isAfter(estEnd) || estEnd.isBefore(estStart)) { //verify end time cannot precede start time
            Alert alert2 = new Alert(Alert.AlertType.INFORMATION);
            alert2.setTitle("Appointment cannot be added.");
            alert2.setHeaderText("Error adding appointment.");
            alert2.setContentText("Appointment end time cannot precede start time.");
            alert2.showAndWait();
        }else if (estStart.toLocalTime().isBefore(LocalTime.of(8, 00)) || estStart.toLocalTime().isAfter(LocalTime.of(21, 45))){
            Alert alert1 = new Alert((Alert.AlertType.ERROR));
            alert1.setTitle("Error");
            alert1.setHeaderText("Start time outside business hours.");
            alert1.setContentText("Please enter times between 8 AM and 9:45 PM EST.");
            alert1.showAndWait();
        } else if (estEnd.toLocalTime().isAfter(LocalTime.of(22,00))){
            Alert alert1 = new Alert((Alert.AlertType.ERROR));
            alert1.setTitle("Error");
            alert1.setHeaderText("End time outside business hours.");
            alert1.setContentText("Please enter times between 8:15 AM and 10PM EST.");
            alert1.showAndWait();
        } else if (exceptionMessage.length() <= 0) {

            Customer myCustomer = CustomerDaoImpl.getCustomer(customerId);
            ObservableList<Appointment> appts = AppointmentDaoImpl.getAppointmentByCustomer(customerId);
            for (Appointment apptByCust : appts) {
                assert myCustomer != null;
                if (myCustomer.getCustomerId() == apptByCust.getCustomerId()) {
                    if (apptByCust.getAppointmentId() != apptId) {
                        if (ldtStart.isEqual(apptByCust.getAppointmentStartTime()))
                            overlap = true;
                        else if (ldtStart.isAfter(apptByCust.getAppointmentStartTime()) && ldtStart.isBefore(apptByCust.getAppointmentEndTime()))
                            overlap = true;
                        else if (ldtEnd.isEqual(apptByCust.getAppointmentEndTime()))
                            overlap = true;
                        else if (ldtEnd.isAfter(apptByCust.getAppointmentStartTime()) && ldtEnd.isBefore(apptByCust.getAppointmentEndTime()))
                            overlap = true;
                        else if (ldtStart.isBefore(apptByCust.getAppointmentStartTime()) && ldtEnd.isAfter(apptByCust.getAppointmentStartTime()))
                            overlap = true;
                        if (overlap) {
                            Alert alert = new Alert(Alert.AlertType.ERROR);
                            alert.setTitle("Error");
                            alert.setHeaderText("Customer appointment overlap.");
                            alert.setContentText("Customer already has an appointment during this time period.");
                            alert.showAndWait();
                            break;
                        } //end if overlap alert
                        }//end if that checks for same appt ID
                    }//end if that checks for customer Id
                }//end for

                if (!overlap) {
                    Appointment appointment = new Appointment(apptId, customerId.getCustomerId(), title, desc, location, type, contactId.getContactId(), userId.getUserId(), ldtStart, ldtEnd);
                    appointmentDao.updateAppointment(appointment);
                    returnMainScreen(event);
                } //end if !overlap
            } //end else if
        } //end method


    /**
     * Selects the appointment information to transfer for updating.
     * @param modifiedAppointment
     */
    public void appointmentInfo (Appointment modifiedAppointment) {
        selectedAppointment = modifiedAppointment;
        for(Customer cust : CustomerDaoImpl.getAllCustomers()) {
            if (cust.getCustomerId() == selectedAppointment.getCustomerId()) {
                updtApptCustCombo.getSelectionModel().select(cust);
                break;
            }
        }

        for(Contact contact : ContactDaoImpl.getAllContacts()){
            if(contact.getContactId() == selectedAppointment.getAppointmentContactId()){
                updtApptContactComboBox.getSelectionModel().select(contact);
            }
        }

        for(User user : UserDaoImpl.getAllUsers()){
            if(user.getUserId() == selectedAppointment.getAppointmentUserId()){
                updtApptUserIdCombo.getSelectionModel().select(user);
            }
        }
        updateApptIdTxtField.setText(String.valueOf(selectedAppointment.getAppointmentId()));
        updtApptDescrTxtBox.setText(String.valueOf(selectedAppointment.getAppointmentDescription()));
        updtApptTitleTxtBox.setText(String.valueOf(selectedAppointment.getAppointmentTitle()));
        updtApptLocationCombo.setValue(selectedAppointment.getAppointmentLocation());
        updtApptTypeCombo.setValue(selectedAppointment.getAppointmentType());
        updtApptDatePicker.setValue(selectedAppointment.getAppointmentStartTime().toLocalDate());
        //time boxes
        updtApptStartTimeHourCombo.setValue(Integer.toString(selectedAppointment.getAppointmentStartTime().toLocalTime().getHour()));
        updtApptStartTimeMinCombo.setValue(Integer.toString(selectedAppointment.getAppointmentStartTime().toLocalTime().getMinute()));
        updtApptEndTimeHourCombo.setValue(Integer.toString(selectedAppointment.getAppointmentEndTime().toLocalTime().getHour()));
        updtApptEndTimeMinCombo.setValue(Integer.toString(selectedAppointment.getAppointmentEndTime().toLocalTime().getMinute()));
        if(updtApptStartTimeMinCombo.getValue().equals("0")){
            updtApptStartTimeMinCombo.setValue("00");
        }
        if(updtApptEndTimeMinCombo.getValue().equals("0")){
            updtApptEndTimeMinCombo.setValue("00");
        }

    }

    /**
     * Initializes the controller class.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<String> locations = FXCollections.observableArrayList ("Board room", "Conference Room", "IT Conference Room");
        updtApptLocationCombo.setItems(locations);

        ObservableList<User> getUsers = UserDaoImpl.getUserId();
        updtApptUserIdCombo.setItems(getUsers);

        ObservableList<Contact> getContacts = ContactDaoImpl.getAllContacts();
        updtApptContactComboBox.setItems(getContacts);

        ObservableList<String> hours = FXCollections.observableArrayList("04", "05", "06", "07","08", "09", "10", "11","12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23");
        updtApptStartTimeHourCombo.setItems(hours);
        updtApptEndTimeHourCombo.setItems(hours);

        ObservableList<String> minutes = FXCollections.observableArrayList("00", "15", "30", "45");
        updtApptStartTimeMinCombo.setItems(minutes);
        updtApptEndTimeMinCombo.setItems(minutes);


        ObservableList<String> types = FXCollections.observableArrayList("Planning Session", "De-Briefing", "Project Wrap-Up");
        updtApptTypeCombo.setItems(types);

        ObservableList<Customer> getCustomers = CustomerDaoImpl.getAllCustomers();
        updtApptCustCombo.setItems(getCustomers);


    }

    /**
     * Return to Main Menu screen. This method will return the user to the Main
     * menu.
     * @param event
     * @throws IOException
     */
    public void returnMainScreen(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("/View_Controller/appointments.fxml"));

        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
}
