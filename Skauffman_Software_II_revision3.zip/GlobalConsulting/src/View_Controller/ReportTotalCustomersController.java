package View_Controller;


import GConsulting.DAO.CustomerDaoImpl;
import GConsulting.DAO.ReportDaoImpl;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import model.Report;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

/**
 * This is the ReportTotalCustomerController.
 * @author Susan Kauffman
 */
public class ReportTotalCustomersController implements Initializable {


    @FXML
    private TableView<Report> totCustomersTableview;

    @FXML
    private TableColumn<Report, String> monthCol;

    @FXML
    private TableColumn<Report, String> typeCol;

    @FXML
    private TableColumn<Report, Integer> countCol;

    @FXML
    private Label totCustomerReportLbl;

    @FXML
    private Button totCustomerOKButton;

    @FXML
    private ComboBox<String> monthComboBox;

    @FXML
    private ComboBox<String> typeComboBox;

    /**
     * Get report button. This will use the selection of the month and type to get a count of the
     * specified appointments.
     * @param event
     * @throws SQLException
     */
    @FXML
    void onActionGetReport(MouseEvent event) throws SQLException {
       String month =  monthComboBox.getValue();
       String type =  typeComboBox.getValue();
       Report reportMonth = ReportDaoImpl.getReportData(month, type);
       ObservableList<Report> rList = FXCollections.observableArrayList();
       rList.add(reportMonth);

       typeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
       monthCol.setCellValueFactory(new PropertyValueFactory<>("Month"));
       countCol.setCellValueFactory(new PropertyValueFactory<>("Count"));
       totCustomersTableview.setItems(rList);


    }

    /**
     * Exit button for report. This will return the user to the Main
     * menu.
     * @param event
     * @throws IOException
     */
    @FXML
    void onActionExitApptsReport(ActionEvent event) throws IOException {
        returnMainScreen(event);

    }
    /**
     * Initializes the controller class.
     * @param resourceBundle
     * @param url
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<String> types = FXCollections.observableArrayList("Planning Session", "De-Briefing", "Project Wrap-Up");
        typeComboBox.setItems(types);
        typeComboBox.getSelectionModel().selectFirst();

        ObservableList<String> months = FXCollections.observableArrayList("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" );
        monthComboBox.setItems(months);
        monthComboBox.getSelectionModel().selectFirst();


    }

    /**
     * Return to Main Menu screen. This method will return the user to the Main
     * menu.
     * @param event
     * @throws IOException
     */
    public void returnMainScreen(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("/View_Controller/appointments.fxml"));

        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
}
