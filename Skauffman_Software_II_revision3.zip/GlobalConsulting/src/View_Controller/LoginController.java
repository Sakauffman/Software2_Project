package View_Controller;

import GConsulting.DAO.AppointmentDaoImpl;
import GConsulting.DAO.UserDaoImpl;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Appointment;
import model.User;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.TimeZone;

/**
 * This is the LoginController Class.
 * @author Susan Kauffman
 */
public class LoginController {
    private AppointmentDaoImpl appointmentDao = new AppointmentDaoImpl();
    private ResourceBundle rb = ResourceBundle.getBundle("main/myProps", Locale.getDefault());
    String login = rb.getString("login");
    String uName = rb.getString("username");
    String passwd = rb.getString("password");
    Stage stage;
    Scene scene;
    @FXML
    private PasswordField passwordPasswordBox;

    @FXML
    private Label passwordLabel;

    @FXML
    private Label usernameLabel;

    @FXML
    private TextField usernameTxtBox;

    @FXML
    private Label userLocationLbl;

    @FXML
    private Button loginButton;

    @FXML
    private TextField userZoneId;
    String filename = "login_activity.txt";

    /**
     * Login Controller method. Not used at this time.
     */
    public LoginController() throws IOException {

    }

    /**
     * Login button. Upon click, will verify login credentials and let user log in or deny log in.
     * Also writes to a file to log all attempts and translates alerts and text into French if applicable.
     */
    @FXML
    void onClickVerifyLogin(ActionEvent event) throws IOException, Exception {
        FileWriter fwriter = new FileWriter(filename, true);
        PrintWriter outputLog = new PrintWriter(fwriter);

        User myUser = UserDaoImpl.getUser(usernameTxtBox.getText());
        ObservableList<User> allUsers = UserDaoImpl.getAllUsers();

        if (myUser == null || passwordPasswordBox == null && Locale.getDefault().getLanguage().equals("fr")) {
            outputLog.println(LocalDateTime.now() + " " + "No user name and/or password entered." + " " + "Unsuccessful Login\n");
            outputLog.close();
            Alert alert1 = new Alert(Alert.AlertType.ERROR);
            alert1.setTitle("Champ vide");
            alert1.setHeaderText("Le champ ne peut pas être vide.");
            alert1.setContentText("Veuillez saisir un nom d'utilisateur valide.");
            alert1.showAndWait();

        } else if (myUser == null || passwordPasswordBox == null && Locale.getDefault().getLanguage().equals("en")) {
            outputLog.println(LocalDateTime.now() + " " + "No user name and/or password entered." + " " + "Unsuccessful Login\n");
            outputLog.close();
            Alert alert1 = new Alert(Alert.AlertType.ERROR);
            alert1.setTitle("Empty field");
            alert1.setHeaderText("Field Cannot Be Empty");
            alert1.setContentText("Please enter a valid Username");
            alert1.showAndWait();

        } else if (myUser.getPassword().equals(passwordPasswordBox.getText()) && Locale.getDefault().getLanguage().equals("fr")) {
            outputLog.println(LocalDateTime.now() + "\n" + "Username: " + myUser.getUserName() + "\n" + "Successful Login\n");
            outputLog.close();

            ObservableList<Appointment> loadAppt = AppointmentDaoImpl.getAppointment15Minute(myUser);
            boolean found = false;
            for (Appointment appt : loadAppt) {
                if (myUser.getUserId() == appt.getAppointmentUserId()) {
                    Alert alertTime = new Alert(Alert.AlertType.INFORMATION);
                    alertTime.setTitle("Alerte de rendez-vous");
                    alertTime.setHeaderText("Rendez-vous à venir");
                    alertTime.setContentText("ID de rendez-vous: " + appt.getAppointmentId() + "Date/heure: " + appt.getAppointmentStartTime());
                    alertTime.showAndWait();
                    found = true;

                }
            }//end for
            if (!found) {
                Alert alertNoAppt = new Alert(Alert.AlertType.INFORMATION);
                alertNoAppt.setTitle("Alerte de rendez-vous");
                alertNoAppt.setHeaderText("Pas de rendez-vous à venir.");
                alertNoAppt.setContentText("Il n'y a pas de rendez-vous à venir dans les 15 prochaines mins.");
                alertNoAppt.showAndWait();
            }
            Parent root = FXMLLoader.load(getClass().getResource("/View_Controller/appointments.fxml"));
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } else if (myUser.getPassword().equals(passwordPasswordBox.getText())) {
            outputLog.println(LocalDateTime.now() + "\n" + "Username: " + myUser.getUserName() + "\n" + "Successful Login\n");
            outputLog.close();

            ObservableList<Appointment> loadAppt2 = AppointmentDaoImpl.getAppointment15Minute(myUser);
            boolean found2 = false;
            for (Appointment appt : loadAppt2) {
                if (myUser.getUserId() == appt.getAppointmentUserId()) {
                    Alert alertTime = new Alert(Alert.AlertType.INFORMATION);
                    alertTime.setTitle("Appointment Alert");
                    alertTime.setHeaderText("Upcoming Appointment");
                    alertTime.setContentText("Appt ID: " + appt.getAppointmentId() + "Date/Time: " + appt.getAppointmentStartTime());
                    alertTime.showAndWait();
                    found2 = true;

                }
            }//end for
            if (!found2) {
                Alert alertNoAppt = new Alert(Alert.AlertType.INFORMATION);
                alertNoAppt.setTitle("Appointment Alert");
                alertNoAppt.setHeaderText("No Upcoming Appointments");
                alertNoAppt.setContentText("There are no appointments within next 15 mins.");
                alertNoAppt.showAndWait();
            }


            Parent root = FXMLLoader.load(getClass().getResource("/View_Controller/appointments.fxml"));
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }//end else if


        else if (!myUser.getPassword().equals(passwordPasswordBox.getText()) && Locale.getDefault().getLanguage().equals("fr")) {
            outputLog.println(LocalDateTime.now() + "\n" + "Invalid Username or Password entered.\n" + "User name entered: " + usernameTxtBox.getText() + "\n" + "Password entered : " + passwordPasswordBox.getText() + "\n" + "Unsuccessful login.\n");
            outputLog.close();
            Alert alert2 = new Alert(Alert.AlertType.ERROR);
            alert2.setTitle("Entrée non valide.");
            alert2.setHeaderText("Nom d'utilisateur ou mot de passe non valide.");
            alert2.setContentText("Le nom d'utilisateur ou le mot de passe ne correspondent pas. Accès refusé.");
            alert2.showAndWait();

        } else if (!myUser.getPassword().equals(passwordPasswordBox.getText()) && Locale.getDefault().getLanguage().equals("en")) {
            outputLog.println(LocalDateTime.now() + "\n" + "Invalid Username or Password entered.\n" + "User name entered: " + usernameTxtBox.getText() + "\n" + "Password entered : " + passwordPasswordBox.getText() + "\n" + "Unsuccessful login.\n");
            outputLog.close();
            Alert alert2 = new Alert(Alert.AlertType.ERROR);
            alert2.setTitle("Invalid Entry");
            alert2.setHeaderText("Invalid Username or Password");
            alert2.setContentText("Username or Password do not match. Access Denied");
            alert2.showAndWait();

        }
    }

    /**
     * Placeholder for ZoneID.
     */
    @FXML
    void onLoadZoneId(ActionEvent event) {

        ZoneId localZoneId = ZoneId.of(TimeZone.getDefault().getID());
        userZoneId.setText(String.valueOf(localZoneId));

    }


    /**
     * Initializes the controller.
     */
    public void initialize(){
        ZoneId localZoneId = ZoneId.of(TimeZone.getDefault().getID());
        userZoneId.setText(String.valueOf(localZoneId));

        if(Locale.getDefault().getLanguage().equals("fr")){
            loginButton.setText(rb.getString("login"));
            usernameLabel.setText(rb.getString("username"));
            passwordLabel.setText(rb.getString("password"));
            userLocationLbl.setText(rb.getString("location"));


        }

    }
}









