package View_Controller;

import GConsulting.DAO.AppointmentDaoImpl;
import GConsulting.DAO.ContactDaoImpl;
import GConsulting.DAO.UserDaoImpl;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.fxml.LoadException;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Appointment;
import model.Contact;
import model.User;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ResourceBundle;

/**
 * This is the ReportSchedByContactController Class. This will show a list of appointments per contact.
 */
public class ReportSchedByContactController implements Initializable {
    @FXML
    private Label reportSchedLbl;

    @FXML
    private TableView<Appointment> reportSBUTableView;

    @FXML
    private TableColumn<Appointment, Integer > reportSBUApptIDCol;

    @FXML
    private TableColumn<Appointment, String> reportSBUTitleCol;

    @FXML
    private TableColumn<Appointment, String> reportSBUTypeCol;

    @FXML
    private TableColumn<Appointment, String> reportSBUDescriptionCol;

    @FXML
    private TableColumn<Appointment, LocalDateTime> reportSBUStartDTCol;

    @FXML
    private TableColumn<Appointment, LocalDateTime> reportSBUEndDTCol;

    @FXML
    private TableColumn<Appointment, Integer> reportSBUCustIDCol;

    @FXML
    private Button reportSBUOKButton;

    @FXML
    private ComboBox<Contact> reportSBConComboBox;

    @FXML
    private Label reportSBUSelectUserLbl;

    /**
     * Exit button for report. This will return the user to the Main
     * menu.
     * @param event
     */
    @FXML
    void onActionExitSchedReport(ActionEvent event) throws IOException {
        returnMainScreen(event);

    }
    /**
     * Show list of contacts to select associated appointments. This method will allow the selection of the contact and
     * once selected, will show the appointments associated with that contact.
     * This is a lambda that adds function to the program by filtering the appointments to the appropriate contact.
     * @param event
     */
    @FXML
    void onActionShowContactsAppt(ActionEvent event) {

        ObservableList<Appointment> aList = AppointmentDaoImpl.getAppointment();
        ObservableList<Appointment> cList = aList.filtered(c ->{
         if(c.getAppointmentContactId() == reportSBConComboBox.getValue().getContactId())
            return true;
        return false;
    });
    reportSBUTableView.setItems(cList);
    }



    /**
     * Initializes the controller class.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<Contact> getContacts = ContactDaoImpl.getAllContacts();
        reportSBConComboBox.setItems(getContacts);

        reportSBUApptIDCol.setCellValueFactory(new PropertyValueFactory<>("AppointmentId"));
        reportSBUTitleCol.setCellValueFactory(new PropertyValueFactory<>("AppointmentTitle"));
        reportSBUDescriptionCol.setCellValueFactory(new PropertyValueFactory<>("AppointmentDescription"));
        reportSBUTypeCol.setCellValueFactory(new PropertyValueFactory<>("AppointmentType"));
        reportSBUStartDTCol.setCellValueFactory(new PropertyValueFactory<>("AppointmentStartTime"));
        reportSBUEndDTCol.setCellValueFactory(new PropertyValueFactory<>("AppointmentEndTime"));
        reportSBUCustIDCol.setCellValueFactory(new PropertyValueFactory<>("CustomerId"));

    }

    /**
     * Return to Main Menu screen. This method will return the user to the Main
     * menu.
     * @param event
     */
    public void returnMainScreen(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("/View_Controller/appointments.fxml"));

        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
}
