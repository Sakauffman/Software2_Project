package View_Controller;


import GConsulting.DAO.CountryDaoImpl;
import GConsulting.DAO.CustomerDaoImpl;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Country;
import model.Customer;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/**
 * This is the ReportCustomController. The report created is how many customers
 * are in each country.
 * @author Susan Kauffman
 */
public class ReportCustomController implements Initializable {

    @FXML
    private Label customReprtLbl;

    @FXML
    private TableView<Customer> customReportTableView;

    @FXML
    private TableColumn<Customer, String> custNameCol;

    @FXML
    private TableColumn<Customer, String> countryCol;

    @FXML
    private Button customReportButton;

    @FXML
    private ComboBox<Country> countryComboBox;

    /**
     * Exit button for report. This will return the user to the Main
     * menu.
     * @param event
     * @throws IOException
     */
    @FXML
    void onActionExitCustomReport(ActionEvent event) throws IOException {
        returnMainScreen(event);

    }
    /**
     * Show list of countries to use to select list of customers in a country. This method will allow the selection of a country
     * and return the names of the customers in that country.
     * This is a lambda that adds function to the program by filtering the customers to the appropriate country and allows the company to view
     * the list of customers.
     * @param event
     */
    @FXML
    void onActionSelectCountryCustomer(ActionEvent event) {
        ObservableList<Customer> clist = CustomerDaoImpl.getAllCustomers();
        ObservableList<Customer> clistfiltered = clist.filtered(c ->{
            if(c.getCountryId() == countryComboBox.getValue().getCountryId())
                return true;
            return false;
        });
        customReportTableView.setItems(clistfiltered);


    }
    /**
     * Initializes the controller class.
     * @param resourceBundle
     * @param url
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<Country> getCountries = CountryDaoImpl.countryList;
        countryComboBox.setItems(getCountries);

        custNameCol.setCellValueFactory(new PropertyValueFactory<>("CustomerName"));
        countryCol.setCellValueFactory(new PropertyValueFactory<>("Country"));

    }

    /**
     * Return to Main Menu screen. This method will return the user to the Main
     * menu.
     * @param event
     * @throws IOException
     */
    public void returnMainScreen(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("/View_Controller/appointments.fxml"));

        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
}
