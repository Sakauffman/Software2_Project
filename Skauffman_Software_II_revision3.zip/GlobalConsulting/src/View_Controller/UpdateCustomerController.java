package View_Controller;

import GConsulting.DAO.CountryDaoImpl;
import GConsulting.DAO.CustomerDaoImpl;
import GConsulting.DAO.FirstLevelDaoImpl;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Country;
import model.Customer;
import model.FirstLevelDivision;

import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * This is the UpdateCustomerController.
 */
public class UpdateCustomerController implements Initializable {

    private Customer selectedCustomer;
    private String exceptionMessage = new String();

    private CustomerDaoImpl customerDao = new CustomerDaoImpl();

    @FXML
    private TextField updateCustomerIDTxt;

    @FXML
    private TextField updateCustomerNameTxt;

    @FXML
    private TextField updateCustomerPhoneTxt;

    @FXML
    private TextField updateCustomerPCTxt;

    @FXML
    private TextField updateCustomerAddressTxt;

    @FXML
    private Button updateCustomerSaveButton;

    @FXML
    private Button updateCustomerCancelButton;

    @FXML
    private ComboBox<Country> countryComboBox = null;

    @FXML
    private ComboBox<FirstLevelDivision> updateCustFLDComboBox = null;

    /**
     * Returns user to main appointment screen. No changes are saved.
     * @param event
     * @throws IOException
     */
    @FXML
    void onClickExitToMain(ActionEvent event) throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "This will clear all entered values. Do you want to continue?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK)
            returnMainScreen(event);
    }

    /**
     * This loads the countries into the countryComboBox.
     * @param event
     */
    @FXML
    void onClickLoadCountry(ActionEvent event) {
       ObservableList<FirstLevelDivision> loadFLD = FirstLevelDaoImpl.divisionsList;
        Country country = countryComboBox.getValue();

        ObservableList<FirstLevelDivision> filterFLD = FXCollections.observableArrayList();
        for(FirstLevelDivision fld: loadFLD){
            if(country.getCountryId() == fld.getCountryID()){
                filterFLD.add(fld);
            }

        }
        updateCustFLDComboBox.setItems(filterFLD);

    }

    /**
     * This loads the First Level Divisions into the updateCustFLDComboBox.
     * The FLD is filtered based on selected country.
     * @param event
     */
    @FXML
    void onClickLoadFLD(ActionEvent event) {

    }

    public void customerInfo (Customer modifiedCustomer){
        selectedCustomer = modifiedCustomer;

       for(Country c : CountryDaoImpl.countryList) {
            if (c.getCountryId() == modifiedCustomer.getCountryId()) {
                countryComboBox.getSelectionModel().select(c);
                break;
            }
        }
       filterComboBoxes();

       for(FirstLevelDivision fld : FirstLevelDaoImpl.filteredDivisionList){
            if(fld.getFLDId() == modifiedCustomer.getDivisionId()){
                updateCustFLDComboBox.getSelectionModel().select(fld);
                break;

            }
        }
        updateCustomerIDTxt.setText(String.valueOf(selectedCustomer.getCustomerId()));
        updateCustomerNameTxt.setText(selectedCustomer.getCustomerName());
        updateCustomerAddressTxt.setText(selectedCustomer.getCustomerAddress());
        updateCustomerPCTxt.setText(selectedCustomer.getCustomerPostalCode());
        updateCustomerPhoneTxt.setText(selectedCustomer.getCustomerPhone());

    }

    /**
     * Update Customer info Save Button. This will save the updated customer information.
     * @param event
     * @throws SQLException
     * @throws IOException
     */
    @FXML
    void onClickSaveUpdatedCustomer(ActionEvent event) throws SQLException, IOException {

        int customerId = Integer.parseInt(updateCustomerIDTxt.getText());
        String name = updateCustomerNameTxt.getText();
        String phone = updateCustomerPhoneTxt.getText();
        String address = updateCustomerAddressTxt.getText();
        String postalCode = updateCustomerPCTxt.getText();
        FirstLevelDivision fld = updateCustFLDComboBox.getValue();
        Country country = countryComboBox.getValue();

        exceptionMessage = Customer.isDataValid(name, address, postalCode, phone, fld.toString(), country.toString(), exceptionMessage);
        if (exceptionMessage.length() > 0) {
            Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
            alert1.setTitle("Customer cannot be added.");
            alert1.setHeaderText("Error adding customer");
            alert1.setContentText(exceptionMessage);
            alert1.showAndWait();
            exceptionMessage = "";
        }
        else {
            Customer customerUpdated = new Customer(customerId, name, address, postalCode, phone, fld.getFLDId(), fld.getFLDName(), country.getCountryName(), country.getCountryId());
            customerDao.updateCustomer(customerUpdated);

            returnMainScreen(event);
        }
    }


    /**
     * Initializes the controller.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<Country> loadCountry = CountryDaoImpl.countryList;
        countryComboBox.setItems(loadCountry);
        countryComboBox.getSelectionModel().select(0);

    }

    /**
     * This method will filter the FLD based upon the country selected.
     */
    public void filterComboBoxes (){
        FirstLevelDaoImpl.filteredDivisionList.clear();

        for(FirstLevelDivision fld : FirstLevelDaoImpl.divisionsList){
            if(fld.getCountryID() == countryComboBox.getSelectionModel().getSelectedItem().getCountryId())
                FirstLevelDaoImpl.filteredDivisionList.add(fld);

        }

        updateCustFLDComboBox.setItems(FirstLevelDaoImpl.filteredDivisionList);
        updateCustFLDComboBox.getSelectionModel().select(0);
    }


    /**
     * Return to Main Menu screen. This method will return the user to the Main
     * menu.
     * @param event
     * @throws IOException
     */
    public void returnMainScreen(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("/View_Controller/appointments.fxml"));

        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
}