package View_Controller;

import GConsulting.DAO.AppointmentDaoImpl;
import GConsulting.DAO.CustomerDaoImpl;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Appointment;
import model.Customer;
import utils.DBConnection;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;

public class AppointmentController implements Initializable {
    Stage stage;

    private CustomerDaoImpl customerDao = new CustomerDaoImpl();
    private AppointmentDaoImpl appointmentDao = new AppointmentDaoImpl();

    @FXML
    private TableView<Appointment> apptTableView;

    @FXML
    private TableColumn<Appointment, Integer> apptIdColLbl;

    @FXML
    private TableColumn<Appointment, String> titleColLbl;

    @FXML
    private TableColumn<Appointment, String> descriptionColLbl;

    @FXML
    private TableColumn<Appointment, String> locationColLbl;

    @FXML
    private TableColumn<Appointment, String> contactColLbl;

    @FXML
    private TableColumn<Appointment, String> typeColLbl;

    @FXML
    private TableColumn<Appointment, LocalDateTime> startCollbl;

    @FXML
    private TableColumn<Appointment, LocalDateTime> endColLbl;

    @FXML
    private TableColumn<Customer, Integer> customerIdColLbl;

    @FXML
    private RadioButton allApptsRadioButton;

    @FXML
    private RadioButton monthApptToggleButton;


    @FXML
    private ToggleGroup apptToggleGroup;

    @FXML
    private RadioButton weeklyApptsRadioButton;

    @FXML
    private Button newApptButton;

    @FXML
    private Button updateApptButton;

    @FXML
    private Button delApptButton;

    @FXML
    private Button monthlyReportButton;

    @FXML
    private Button customReportButton;

    @FXML
    private Button scheduleByUserButton;

    @FXML
    private TableView<Customer> custDirectoryTableview;

    @FXML
    private TableColumn<Customer, Integer> directoryCustIdCol;

    @FXML
    private TableColumn<Customer, Integer> directoryNameCol;

    @FXML
    private TableColumn<Customer, String> directoryAddressCol;

    @FXML
    private TableColumn<Customer, String> directoryStateProvCol;

    @FXML
    private TableColumn<Customer, String> directoryPostalCodeCol;

    @FXML
    private TableColumn<Customer, String> directoryPhoneCol;

    @FXML
    private Button newCustomerButton;

    @FXML
    private Button updateCustomerButton;

    @FXML
    private Button delCustomerButton;

    @FXML
    private Button exitProgramButton;

    /**
     * Transfers the user to the New Customer info entry screen.
     */
    @FXML
    void onCLickNewCustomer(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/View_Controller/newCustomer.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    /**
     * Takes user to customers by country report.
     */
    @FXML
    void onClickCustomReport(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/View_Controller/reportCustom.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }
    /**
     * Deletes appointment from database. This will permanently remove appointment information
     * from the system.
     */
    @FXML
    void onClickDeleteAppointment(ActionEvent event) throws SQLException {
        Appointment appointment = apptTableView.getSelectionModel().getSelectedItem();
        if (appointment == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Please select an Appointment to delete.");
            alert.showAndWait();
            return;
        }

        else if(appointment != null && Locale.getDefault().getLanguage().equals("en")) {
                int apptId2 = appointment.getAppointmentId();
                String type2 = appointment.getAppointmentType();
                Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION);
                alert1.setTitle("Confirm delete appointment");
                alert1.setHeaderText("Confirm delete appointment");
                alert1.setContentText("This will delete Appt ID: " + apptId2 + " " + type2 + ".");
                Optional<ButtonType> result2 = alert1.showAndWait();

                if (result2.get() == ButtonType.OK) {
                    appointmentDao.deleteAppointment(appointment);
                }
            }
            apptTableView.setItems(AppointmentDaoImpl.getAppointment());

        }

        /**
         * Deletes customer from database. This will permanently remove a customer
         * information set from the system.
         */
        @FXML
        void onClickDeleteCustomer (ActionEvent event) throws SQLException {
            Customer c = custDirectoryTableview.getSelectionModel().getSelectedItem();

            if(c == null){
                Alert alert = new Alert(Alert.AlertType.ERROR, "Please select a customer to delete.");
                Optional<ButtonType> result = alert.showAndWait();
                return;
            }

            else if(c != null) {

                Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION);
                alert1.setTitle("Confirm Delete Customer");
                alert1.setHeaderText("Confirm delete customer");
                alert1.setContentText("Are you sure you want to delete this customer?");
                Optional<ButtonType> result = alert1.showAndWait();
                if (result.get() == ButtonType.OK) {
                    customerDao.deleteCustomer(c);
                    apptTableView.setItems(AppointmentDaoImpl.getAppointment());
                    custDirectoryTableview.setItems(CustomerDaoImpl.getAllCustomers());
                }

            }
        }

    /**
     * Takes user to the Monthly user report screen.
     */
    @FXML
    void onClickMonthlyUserReport(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/View_Controller/reportTotalCustomers.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }
    /**
     * Takes user to the new appointment information entry screen.
     */
    @FXML
    void onClickNewAppointment(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/View_Controller/newAppointment.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }
    /**
     * Takes the user to the report screen for schedule by user.
     */
    @FXML
    void onClickScheduleByUser(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/View_Controller/reportSchedbyContact.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }
    /**
     * Moves the user to the update appointment screen. The previously saved appointment information
     * will move into the next screen when clicked.
     */
    @FXML
    void onClickUpdateAppointment(ActionEvent event) throws IOException {
        Appointment a = apptTableView.getSelectionModel().getSelectedItem();
        if(a == null){
            Alert alert1 = new Alert(Alert.AlertType.ERROR, "Please select an Appointment to update.");
            Optional<ButtonType> result = alert1.showAndWait();
            return;
        }
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/View_Controller/updateAppointment.fxml"));
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        Parent root = loader.load();

        UpdateAppointmentController UpdateApptController = loader.getController();
        UpdateApptController.appointmentInfo(a);
        stage.setScene((new Scene(root)));
        stage.show();
    }

    /**
     * Moves the to the update customer screen. The previously saved customer information
     * will move into the next screen when clicked.
     */
    @FXML
    void onClickUpdateCustomer(ActionEvent event) throws IOException {
        Customer c = custDirectoryTableview.getSelectionModel().getSelectedItem();
        if (c == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Please select a Customer to update.");
            Optional<ButtonType> result = alert.showAndWait();
            return;
        }
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/View_Controller/updateCustomer.fxml"));
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Parent root = loader.load();

        UpdateCustomerController UpdateCustController = loader.getController();
        UpdateCustController.customerInfo(c);
        stage.setScene((new Scene(root)));
        stage.show();

    }
    /**
     * Exits the program.
     */
    @FXML
    void onClickExitProgram(ActionEvent event) {
        DBConnection.closeConnection();
        System.exit(0);

    }
    /**
     * Radio button to show all appointments. When selected, all appointments in the database
     * will populate.
     */
    @FXML
    void onClickLoadALL(ActionEvent event) {
        if(this.allApptsRadioButton.isSelected()) {
            apptIdColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentId"));
            titleColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentTitle"));
            descriptionColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentDescription"));
            locationColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentLocation"));
            contactColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentContactId"));
            typeColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentType"));
            startCollbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentStartTime"));
            endColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentEndTime"));
            customerIdColLbl.setCellValueFactory(new PropertyValueFactory<>("CustomerId"));
            apptTableView.setItems(AppointmentDaoImpl.getAppointment());
        }
    }
    /**
     * Radio button to show one months worth of appointments. When selected, 31 days of appointments in the database
     * will populate.
     */
    @FXML
    void onClickLoadMonthly(ActionEvent event) {
        if(this.monthApptToggleButton.isSelected()){
            apptIdColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentId"));
            titleColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentTitle"));
            descriptionColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentDescription"));
            locationColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentLocation"));
            contactColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentContactId"));
            typeColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentType"));
            startCollbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentStartTime"));
            endColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentEndTime"));
            customerIdColLbl.setCellValueFactory(new PropertyValueFactory<>("CustomerId"));
            apptTableView.setItems(AppointmentDaoImpl.monthlyAppointments());
        }

    }
    /**
     * Radio button to show weekly appointments. When selected, 7 days worth of appointments in the database
     * will populate.
     */
    @FXML
    void onClickLoadWeekly(ActionEvent event) {
        if(this.weeklyApptsRadioButton.isSelected()){
            apptIdColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentId"));
            titleColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentTitle"));
            descriptionColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentDescription"));
            locationColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentLocation"));
            contactColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentContactId"));
            typeColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentType"));
            startCollbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentStartTime"));
            endColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentEndTime"));
            customerIdColLbl.setCellValueFactory(new PropertyValueFactory<>("CustomerId"));
            apptTableView.setItems(AppointmentDaoImpl.weeklyAppointments());
        }

    }

    /**
     * Initializes the controller.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //need to set up ALL, Weekly, Monthly views
        apptToggleGroup = new ToggleGroup();
        this.monthApptToggleButton.setToggleGroup(apptToggleGroup);
        this.weeklyApptsRadioButton.setToggleGroup(apptToggleGroup);
        this.allApptsRadioButton.setToggleGroup(apptToggleGroup);

        if(this.allApptsRadioButton.isSelected()) {
            apptIdColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentId"));
            titleColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentTitle"));
            descriptionColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentDescription"));
            locationColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentLocation"));
            contactColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentContactId"));
            typeColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentType"));
            startCollbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentStartTime"));
            endColLbl.setCellValueFactory(new PropertyValueFactory<>("AppointmentEndTime"));
            customerIdColLbl.setCellValueFactory(new PropertyValueFactory<>("CustomerId"));
            apptTableView.setItems(AppointmentDaoImpl.getAppointment());
        }

        directoryCustIdCol.setCellValueFactory(new PropertyValueFactory<>("CustomerId"));
        directoryNameCol.setCellValueFactory(new PropertyValueFactory<>("CustomerName"));
        directoryAddressCol.setCellValueFactory(new PropertyValueFactory<>("CustomerAddress"));
        directoryStateProvCol.setCellValueFactory(new PropertyValueFactory<>("Division"));
        directoryPostalCodeCol.setCellValueFactory(new PropertyValueFactory<>("CustomerPostalCode"));
        directoryPhoneCol.setCellValueFactory(new PropertyValueFactory<>("CustomerPhone"));
        custDirectoryTableview.setItems(CustomerDaoImpl.getAllCustomers());







    }

}
