package main;

import GConsulting.DAO.CountryDaoImpl;
import GConsulting.DAO.FirstLevelDaoImpl;
import GConsulting.DAO.UserDaoImpl;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import utils.DBConnection;

import java.io.IOException;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * This is the main class of the application.
 * @author Susan Kauffman
 */
public class Main extends Application {


    @Override
    public void start(Stage primaryStage) throws Exception, IOException{

        Parent root = FXMLLoader.load(getClass().getResource("/View_Controller/login.fxml"));
        primaryStage.setTitle("Global Consulting Corporation");
        primaryStage.setScene(new Scene(root, 497, 290));
        primaryStage.show();


    }

    /**
     * This is the main method.
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        DBConnection.startConnection();
        CountryDaoImpl.selectCountry(); //loads country
        FirstLevelDaoImpl.selectDivisions(); //loads divisions
        UserDaoImpl.getAllUsers(); //loads users
        launch(args);
        DBConnection.closeConnection();
    }
}
